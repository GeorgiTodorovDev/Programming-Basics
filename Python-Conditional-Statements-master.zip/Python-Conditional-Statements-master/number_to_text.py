a = int(input())
if a == 1:
    print('one')
elif a == 2:
    print('two')
elif a == 3:
    print('three')
elif a == 4:
    print('four')
elif a == 5:
    print('five')
elif a == 6:
    print('six')
elif a == 7:
    print('seven')
elif a == 8:
    print('eight')
elif a == 9:
    print('nine')
else:
    print('number too big')