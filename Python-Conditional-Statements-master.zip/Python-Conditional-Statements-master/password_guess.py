text = str(input())
if text == 's3cr3t!P@ssw0rd':
    print("Welcome")
else:
    print("Wrong password!")