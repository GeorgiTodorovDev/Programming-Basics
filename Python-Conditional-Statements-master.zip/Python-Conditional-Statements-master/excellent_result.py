grade = float(input())
if grade >= 5.5:
    print("Excellent!")