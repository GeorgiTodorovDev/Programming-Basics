a = int(input())
if a > 200:
    print('Greater than 200')
elif 100 <= a <= 200:
    print('Between 100 and 200')
else:
    print('Less than 100')