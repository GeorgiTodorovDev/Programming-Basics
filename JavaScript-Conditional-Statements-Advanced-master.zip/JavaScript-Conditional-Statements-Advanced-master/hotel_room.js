function solve(a1, a2) {
    let month = String(a1);
    let nights = Number(a2);
    let studio = 0.0;;
    let apartment = 0.0;
    if (month == 'May' || month == 'October') {
        if (nights > 7 && nights <= 14) {
            studio = 50 * nights * 0.95;
            apartment = 65 * nights;
        } else if (nights > 14) {
            studio = 50 * nights * 0.7;
            apartment = 65 * nights * 0.9;
        } else {
            studio = 50 * nights;
            apartment = 65 * nights;
        }
    } else if (month == 'June' || month == 'September') {
        if (nights > 14) {
            studio = 75.2 * nights * 0.8;;
            apartment = 68.7 * nights * 0.9;
        } else {
            studio = 75.2 * nights;
            apartment = 68.7 * nights;
        }
    } else if (month == 'July' || month == 'August') {
        if (nights > 14) {
            studio = 76 * nights;
            apartment = 77 * nights * 0.9;
        } else {
            studio = 76 * nights;
            apartment = 77 * nights;
        } 
    }
    console.log(`Apartment: ${apartment.toFixed(2)} lv.`)
    console.log(`Studio: ${studio.toFixed(2)} lv.`)
}
solve("May", 15)
solve('June', 14)
solve('August', 20)