function solve(a1, a2, a3) {
    let type = String(a1);
    let count = Number(a2);
    let budget = Number(a3);
    let sum = 0.0;
    if (type == 'Roses') {
        if (count > 80) {
            sum = count * 5;
            sum *= 0.9;
        } else {
            sum = count * 5;
        }
    } else if (type == 'Dahlias') {
        if (count > 90) {
            sum = count * 3.8;
            sum *= 0.85;
        } else {
            sum = count * 3.8;
        }
    } else if (type == 'Tulips') {
        if (count > 80) {
            sum = count * 2.8;
            sum *= 0.85;
        } else {
            sum = count * 2.8;
        }
    } else if (type == 'Narcissus') {
        if (count < 120) {
            sum = count * 3;
            sum *= 1.15;
        } else {
            sum = count * 3;
        }
    } else if (type == 'Gladiolus') {
        if (count < 80) {
            sum = count * 2.5;
            sum *= 1.2;
        } else {
            sum = count * 2.5;
        }
    }
    if (budget >= sum) {
        console.log(`Hey, you have a great garden with ${count} ${type} and ${Math.abs(budget - sum).toFixed(2)} leva left.`)
    } else {
        console.log(`Not enough money, you need ${Math.abs(budget - sum).toFixed(2)} leva more.`)
    }

}
solve("Roses", 55, 250)
solve("Tulips", 88, 260)
solve("Narcissus", 119, 360)