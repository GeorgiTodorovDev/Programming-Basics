function solve(a1) {
    let a = Number(a1);
    if (a == 1) {
        console.log("Monday")
    } else if (a == 2) {
        console.log("Tuesday")
    } else if (a == 3) {
        console.log("Wednesday")
    } else if (a == 4) {
        console.log("Thursday")
    } else if (a == 5) {
        console.log("Friday")
    } else if (a == 6) {
        console.log("Saturday")
    } else if (a == 7) {
        console.log("Sunday")
    } else {
        console.log("Error")
    }
}
solve(1);
solve(2);
solve(3);
solve(4);
solve(5);
solve(6);
solve(7);
solve(8);