function solve(a1, a2) {
    let budget = Number(a1);
    let season = String(a2);
    let classCar = ""
    let carType = ""
    if (budget <= 100) {
        classCar = "Economy class"
        if (season == 'Summer') {
            carType = "Cabrio"
            budget *= 0.35
        } else if (season == "Winter") {
            carType = "Jeep"
            budget *= 0.65
        }
    } else if (100 < budget && budget <= 500) {
        classCar = "Compact class"
        if (season == 'Summer') {
            carType = "Cabrio"
            budget *= 0.45
        } else if (season == "Winter") {
            carType = "Jeep"
            budget *= 0.8
        }
    } else if (budget > 500) {
        classCar = "Luxury class"
        carType = "Jeep"
        budget *= 0.9
    }
    console.log(classCar)
    console.log(`${carType} - ${budget.toFixed(2)}`)
} 
solve(450, 'Summer')
