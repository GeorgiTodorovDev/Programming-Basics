function solve(a1, a2, a3) {
    let type = String(a1);
    let rows = Number(a2);
    let columns = Number(a3);
    if (type == 'Premiere') {
        console.log((rows * columns * 12).toFixed(2));
    } else if (type == 'Normal') {
        console.log((rows * columns * 7.5).toFixed(2));
    } else {
        console.log((rows * columns * 5).toFixed(2));
    }
}
solve("Premiere", 10, 12)
solve("Normal", 21, 13)
solve("Discount", 12, 30)