function solve(a1) {
    let a = String(a1);
    switch (a) {
        case "Monday":
        case "Tuesday":
        case "Wednesday":
        case "Thursday":
        case "Friday":
            console.log("Working day")
            break;
        case "Saturday":
        case "Sunday":
            console.log("Weekend")
            break;
        default:
            console.log("Error")
            break;
    }
}
solve("Monday");
solve("Sunday");
solve("April");