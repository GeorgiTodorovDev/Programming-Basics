function solve(a1, a2, a3, a4, a5, a6) {
    let x1 = Number(a1);
    let y1 = Number(a2);
    let x2 = Number(a3);
    let y2 = Number(a4);
    let x = Number(a5);
    let y = Number(a6);
    let f1 = ((x == x1 || x == x2) && (y >= y1 && y <= y2)) 
    let f2 = ((y == y1 || y == y2) && (x >= x1 && x <= x2))
    if (f1 || f2) {
        console.log("Border")
    } else {
        console.log("Inside / Outside")
    }
}
solve(2, -3, 12, 3, 8, -1)
solve(2, -3, 12, 3, 12, -1)