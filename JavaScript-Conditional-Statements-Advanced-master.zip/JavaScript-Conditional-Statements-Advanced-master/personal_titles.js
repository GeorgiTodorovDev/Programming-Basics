function solve(a1, a2) {
    let a = Number(a1);
    let b = String(a2);
    if (b == 'm') {
        if (a >= 16) {
            console.log("Mr.");
        } else {
            console.log("Master")
        }
    } else if (b == 'f') {
        if (a >= 16) {
            console.log("Ms.")
        } else {
            console.log("Miss")
        }
    }
}
solve(12, 'f');
solve(17, 'm');
solve(25, 'f')
solve(13.5, 'm')