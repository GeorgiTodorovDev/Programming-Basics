function solve(a1, a2) {
    let season = String(a1)
    let kmPerMonth = Number(a2)
    let sum = 0
    if (season == 'Spring' || season == 'Autumn') {
        if (kmPerMonth <= 5000) {
            kmPerMonth *= 4 * 0.75 * 0.9
        } else if (5000 < kmPerMonth && kmPerMonth <= 10000) {
            kmPerMonth *= 4 * 0.95 * 0.9
        } else if (10000 < kmPerMonth && kmPerMonth <= 20000) {
            kmPerMonth *= 4 * 1.45 * 0.9
        }
    } else if (season == 'Summer') {
        if (kmPerMonth <= 5000) {
            kmPerMonth *= 4 * 0.9 * 0.9
        } else if (5000 < kmPerMonth && kmPerMonth <= 10000) {
            kmPerMonth *= 4 * 1.1 * 0.9
        } else if (10000 < kmPerMonth && kmPerMonth <= 20000) {
            kmPerMonth *= 4 * 1.45 * 0.9
        }
    } else if (season == 'Winter') {
        if (kmPerMonth <= 5000) {
            kmPerMonth *= 4 * 1.05 * 0.9
        } else if (5000 < kmPerMonth && kmPerMonth <= 10000) {
            kmPerMonth *= 4 * 1.25 * 0.9
        } else if (10000 < kmPerMonth && kmPerMonth <= 20000) {
            kmPerMonth *= 4 * 1.45 * 0.9
        }
    }
    console.log(`${kmPerMonth.toFixed(2)}`)
}
solve('Summer', 3455)
solve('Winter', 4350)
solve('Spring', 1600)
solve('Winter', 5678)
solve('Autumn', 8600)
solve('Winter', 16042)
solve('Spring', 16942)