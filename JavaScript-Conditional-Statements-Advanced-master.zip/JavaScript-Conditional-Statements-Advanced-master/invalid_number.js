function solve(a1) {
    let a = Number(a1);
    if (a >= 100 && a <= 200 || a == 0) {
        console.log();
    } else {
        console.log("invalid")
    }
}
solve(75)
solve(150)
solve(220)
solve(199)
solve(-1)
solve(100)
solve(200)
solve(0)