function solve(a1, a2, a3) {
    let n1 = Number(a1);
    let n2 = Number(a2);
    let ops = String(a3);
    let result = 0.0;
    let evenodd = "";
    if (ops == '+') {
        result = n1 + n2;
        if (result % 2 == 0) {
            evenodd = "even";
            console.log(`${n1} ${ops} ${n2} = ${result} - ${evenodd}`)
        } else {
            evenodd = 'odd';
            console.log(`${n1} ${ops} ${n2} = ${result} - ${evenodd}`)
        }
    } else if (ops == '-') {
        result = n1 - n2;
        if (result % 2 == 0) {
            evenodd = "even";
            console.log(`${n1} ${ops} ${n2} = ${result} - ${evenodd}`)
        } else {
            evenodd = 'odd';
            console.log(`${n1} ${ops} ${n2} = ${result} - ${evenodd}`)
        }
    } else if (ops == '*') {
        result = n1 * n2;
        if (result % 2 == 0) {
            evenodd = "even";
            console.log(`${n1} ${ops} ${n2} = ${result} - ${evenodd}`)
        } else {
            evenodd = 'odd';
            console.log(`${n1} ${ops} ${n2} = ${result} - ${evenodd}`)
        }
    } else if (ops == '/') {
        if (n2 != 0) {
            result = n1 / n2;
            console.log(`${n1} ${ops} ${n2} = ${result.toFixed(2)}`)
        } else {
            console.log(`Cannot divide ${n1} by zero`)
        }
    } else if (ops == '%') {
        if (n2 != 0) {
            result = n1 % n2;
            console.log(`${n1} ${ops} ${n2} = ${result}`)
        } else {
            console.log(`Cannot divide ${n1} by zero`)
        } 
    }
}
solve(10, 12, "+")
solve(10, 1, "-")
solve(7, 3, "*")
solve(123, 12, "/")
solve(10, 3, "%")
solve(112, 0, "/")
solve(10, 0, '%')