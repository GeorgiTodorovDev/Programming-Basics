function solve(a1, a2) {
    let budget = Number(a1);
    let season = String(a2);
    let dest = "";
    let vac = "";
    if (budget <= 100) {
        dest = "Bulgaria";
        if (season == 'summer') {
            budget *= 0.3;
            vac = "Camp";
        } else {
            budget *= 0.7;
            vac = "Hotel"
        }
    } else if (budget <= 1000) {
        dest = "Balkans";
        if (season == 'summer') {
            budget *= 0.4;
            vac = "Camp"
        } else {
            budget *= 0.8;
            vac = "Hotel"
        }
    } else {
        dest = "Europe";
        budget *= 0.9;
        vac = "Hotel"
    }
    console.log(`Somewhere in ${dest}`)
    console.log(`${vac} - ${budget.toFixed(2)}`)
}
solve(50, 'summer')
solve(75, 'winter')
solve(312, 'summer')
solve(678.53, 'winter')
solve(1500, 'summer')