function solve(a1) {
    let a = String(a1);
    switch (a) {
        case "dog":
            console.log("mammal");
            break;
        case "crocodile":
        case "tortoise":
        case "snake":
            console.log("reptile");
            break;
        default:
            console.log("unknown")
    }
}
solve("dog");
solve("snake");
solve("cat");