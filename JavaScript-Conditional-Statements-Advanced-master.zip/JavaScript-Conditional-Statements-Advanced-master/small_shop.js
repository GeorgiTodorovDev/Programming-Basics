function solve(a1, a2, a3) {
    let product = String(a1);
    let city = String(a2);
    let qnty = Number(a3);
    if (city == "Sofia") {
        if (product == 'coffee') {
            console.log(qnty * 0.5);
        } else if (product == 'water') {
            console.log(qnty * 0.8);
        } else if (product == 'beer') {
            console.log(qnty * 1.2)
        } else if (product == 'sweets') {
            console.log(qnty * 1.45)
        } else if (product == 'peanuts') {
            console.log(qnty * 1.6)
        }
    } else if (city == 'Plovdiv') {
        if (product == 'coffee') {
            console.log(qnty * 0.4);
        } else if (product == 'water') {
            console.log(qnty * 0.7);
        } else if (product == 'beer') {
            console.log(qnty * 1.15)
        } else if (product == 'sweets') {
            console.log(qnty * 1.3)
        } else if (product == 'peanuts') {
            console.log(qnty * 1.5)
        }
    } else if (city == 'Varna') {
        if (product == 'coffee') {
            console.log(qnty * 0.45);
        } else if (product == 'water') {
            console.log(qnty * 0.7);
        } else if (product == 'beer') {
            console.log(qnty * 1.1)
        } else if (product == 'sweets') {
            console.log(qnty * 1.35)
        } else if (product == 'peanuts') {
            console.log(qnty * 1.55)
        }
    }
}
solve('coffee', 'Varna', 2)
solve('peanuts', 'Plovdiv', 1)
solve('beer', 'Sofia', 6)
solve('water', 'Plovdiv', 3)
solve('sweets', 'Sofia', 2.23)