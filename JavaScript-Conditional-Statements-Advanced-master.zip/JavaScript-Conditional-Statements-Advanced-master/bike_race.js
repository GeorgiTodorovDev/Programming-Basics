function solve(a1, a2, a3) {
    let juniors = Number(a1);
    let seniors = Number(a2);
    let track = String(a3);
    let sum = 0.0;
    if (track == 'trail') {
        sum = juniors * 5.5 + seniors * 7
        sum *= 0.95;
    } else if (track == 'cross-country') {
        if (seniors + juniors >= 50) {
            sum = juniors * 8 + seniors * 9.5;
            sum *= 0.75;
            sum *= 0.95;
        } else {
            sum = juniors * 8 + seniors * 9.5;
            sum *= 0.95;
        }
    } else if (track == 'downhill') {
        sum = juniors * 12.25 + seniors * 13.75;
        sum *= 0.95;
    } else if (track == 'road') {
        sum = juniors * 20 + seniors * 21.5;
        sum *= 0.95;
    }
    console.log(`${sum.toFixed(2)}`)
}
solve(10, 20, "trail")
solve(20, 25, 'cross-country')
solve(30, 25, 'cross-country')
solve(10, 10, 'downhill')
solve(3, 40, 'road')