function solve(a) {
    let ab = Number(a)
    if (ab >= -100 && ab <= 100 && ab != 0) {
        console.log("Yes")
    } else {
        console.log("No ")
    }
}
solve(-25);
solve(25);
solve(0);
