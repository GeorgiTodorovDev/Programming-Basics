function solve(a1, a2, a3, a4) {
    let season = String(a1)
    let group = String(a2)
    let guys = Number(a3)
    let nights = Number(a4)
    let sport = ""
    let sum = 0
    if (season == 'Winter' && group == 'girls') {
        sport = 'Gymnastics'
        if (10 <= guys && guys < 20) {
            sum = guys * nights * 9.6 * 0.95
        } else if (20 <= guys && guys < 50) {
            sum = guys * nights * 9.6 * 0.85
        } else if (50 <= guys) {
            sum = guys * nights * 9.6 * 0.5
        } else {
            sum = guys * nights * 9.6
        }
    } else if (season == 'Winter' && group == 'boys') {
        sport = 'Judo'
        if (10 <= guys && guys < 20) {
            sum = guys * nights * 9.6 * 0.95
        } else if (20 <= guys && guys < 50) {
            sum = guys * nights * 9.6 * 0.85
        } else if (50 <= guys) {
            sum = guys * nights * 9.6 * 0.5
        } else {
            sum = guys * nights * 9.6
        }
    } else if (season == 'Winter' && group == 'mixed') {
        sport = 'Ski'
        if (10 <= guys && guys < 20) {
            sum = guys * nights * 10 * 0.95
        } else if (20 <= guys && guys < 50) {
            sum = guys * nights * 10 * 0.85
        } else if (50 <= guys) {
            sum = guys * nights * 10 * 0.5
        } else {
            sum = guys * nights * 10
        }
    }
    if (season == 'Spring' && group == 'girls') {
        sport = 'Athletics'
        if (10 <= guys && guys < 20) {
            sum = guys * nights * 7.2 * 0.95
        } else if (20 <= guys && guys < 50) {
            sum = guys * nights * 7.2 * 0.85
        } else if (50 <= guys) {
            sum = guys * nights * 7.2 * 0.5
        } else {
            sum = guys * nights * 7.2
        }
    } else if (season == 'Spring' && group == 'boys') {
        sport = 'Tennis'
        if (10 <= guys && guys < 20) {
            sum = guys * nights * 7.2 * 0.95
        } else if (20 <= guys && guys < 50) {
            sum = guys * nights * 7.2 * 0.85
        } else if (50 <= guys) {
            sum = guys * nights * 7.2 * 0.5
        } else {
            sum = guys * nights * 7.2
        }
    } else if (season == 'Spring' && group == 'mixed') {
        sport = 'Cycling'
        if (10 <= guys && guys < 20) {
            sum = guys * nights * 9.5 * 0.95
        } else if (20 <= guys && guys < 50) {
            sum = guys * nights * 9.5 * 0.85
        } else if (50 <= guys) {
            sum = guys * nights * 9.5 * 0.5
        } else {
            sum = guys * nights * 9.5
        }
    }
    if (season == 'Summer' && group == 'girls') {
        sport = 'Volleyball'
        if (10 <= guys && guys < 20) {
            sum = guys * nights * 15 * 0.95
        } else if (20 <= guys && guys < 50) {
            sum = guys * nights * 15 * 0.85
        } else if (50 <= guys) {
            sum = guys * nights * 15 * 0.5
        } else {
            sum = guys * nights * 15
        }
    } else if (season == 'Summer' && group == 'boys') {
        sport = 'Football'
        if (10 <= guys && guys < 20) {
            sum = guys * nights * 15 * 0.95
        } else if (20 <= guys && guys < 50) {
            sum = guys * nights * 15 * 0.85
        } else if (50 <= guys) {
            sum = guys * nights * 15 * 0.5
        } else {
            sum = guys * nights * 15
        }
    } else if (season == 'Summer' && group == 'mixed') {
        sport = 'Swimming'
        if (10 <= guys && guys < 20) {
            sum = guys * nights * 20 * 0.95
        } else if (20 <= guys && guys < 50) {
            sum = guys * nights * 20 * 0.85
        } else if (50 <= guys) {
            sum = guys * nights * 20 * 0.5
        } else {
            sum = guys * nights * 20
        }
    }
    console.log(`${sport} ${sum.toFixed(2)} lv.`)
}
solve('Spring', 'girls', 20, 7)
solve('Winter', 'mixed', 9, 15)
solve('Summer', 'boys', 60, 7)
solve('Spring', 'mixed', 17, 14)