function solve(a1, a2) {
    let deg = Number(a1);
    let daytime = String(a2);
    outfit = "";
    shoes = "";
    if (daytime == 'Morning') { 
        if (deg >= 10 && deg <= 18) {
            outfit = "Sweatshirt";
            shoes = "Sneakers";
            console.log(`It's ${deg} degrees, get your ${outfit} and ${shoes}.`)
        } else if (deg > 18 && deg <= 24) {
            outfit = "Shirt";
            shoes = "Moccasins";
            console.log(`It's ${deg} degrees, get your ${outfit} and ${shoes}.`)
        } else if (deg >= 25) {
            outfit = "T-Shirt";
            shoes = "Sandals";
            console.log(`It's ${deg} degrees, get your ${outfit} and ${shoes}.`)
        }
    } else if (daytime == 'Afternoon') {
        if (deg > 10 && deg <= 18) {
            outfit = "Shirt";
            shoes = "Moccasins";
            console.log(`It's ${deg} degrees, get your ${outfit} and ${shoes}.`)
        } else if (deg > 18 && deg <= 24) {
            outfit = "T-Shirt";
            shoes = "Sandals";
            console.log(`It's ${deg} degrees, get your ${outfit} and ${shoes}.`)
        } else if (deg >= 25) {
            outfit = "Swim Suit";
            shoes = "Barefoot";
            console.log(`It's ${deg} degrees, get your ${outfit} and ${shoes}.`)
        }
    }else if (daytime == 'Evening') {
        if (deg > 10 && deg <= 18) {
            outfit = "Shirt";
            shoes = "Moccasins";
            console.log(`It's ${deg} degrees, get your ${outfit} and ${shoes}.`)
        } else if (deg > 18 && deg <= 24) {
            outfit = "Shirt";
            shoes = "Moccasins";
            console.log(`It's ${deg} degrees, get your ${outfit} and ${shoes}.`)
        } else if (deg >= 25) {
            outfit = "Shirt";
            shoes = "Moccasins";
            console.log(`It's ${deg} degrees, get your ${outfit} and ${shoes}.`)
        }
    }
}
solve(16, 'Morning')
solve(22, 'Afternoon')
solve(28, 'Evening')