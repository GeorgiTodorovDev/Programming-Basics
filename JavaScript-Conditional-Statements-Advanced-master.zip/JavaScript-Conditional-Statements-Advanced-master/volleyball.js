function solve(a1, a2, a3) {
    let year = String(a1);
    let holidays = Number(a2);
    let homeCity = Number(a3);
    let weekendSofia = (48 - homeCity) * 3 / 4;
    let weekendHome = homeCity;
    let weekendHoliday = holidays * 2 / 3;
    let ttlGames = weekendSofia + weekendHome + weekendHoliday;
    if (year == 'leap') {
        ttlGames += ttlGames * 0.15
        console.log(Math.floor(ttlGames));

    } else {
        console.log(Math.floor(ttlGames));
    }
}
solve('normal', 3, 2)
solve('leap', 2, 3)
solve('normal', 11, 6)
solve('leap', 0, 1)
solve('normal', 6, 13)