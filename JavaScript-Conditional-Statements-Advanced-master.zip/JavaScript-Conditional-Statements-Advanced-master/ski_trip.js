function solve(a1, a2, a3) {
    let days = Number(a1);
    let room = String(a2);
    let assess = String(a3);
    let sum = 0.0;
    if (room == 'room for one person') {
        if (days <= 10) {
            sum = (days - 1) * 18;
        } else if (days > 10 && days <=15) {
            sum = (days - 1) * 18;
        } else if (days > 15) {
            sum = (days - 1) * 18;
        }
    } else if (room == 'apartment') {
        if (days <= 10) {
            sum = (days - 1) * 25;
            sum *= 0.7;
        } else if (days > 10 && days <= 15) {
            sum = (days - 1) * 25;
            sum *= 0.65;
        } else if (days > 15) {
            sum = (days - 1) * 25;
            sum *= 0.5;
        }
    } else if (room == 'president apartment') {
        if (days <= 10) {
            sum = (days - 1) * 35;
            sum *= 0.9;
        } else if (days > 10 && days <= 15) {
            sum = (days - 1) * 35;
            sum *= 0.85;
        } else if (days > 15) {
            sum = (days - 1) * 35;
            sum *= 0.8;
        }
    }
    if (assess == 'positive') {
        sum *= 1.25;
        console.log(sum.toFixed(2));
    } else {
        sum *= 0.9;
        console.log(sum.toFixed(2));
    }
}
solve(14, 'apartment', 'positive')
solve(30, 'president apartment', 'negative')
solve(12, 'room for one person', 'positive')
solve(2, 'apartment', 'positive')