function solve(a1) {
    let a = String(a1);
    if (a == 'Monday') {
        console.log(12)
    } else if (a == 'Tuesday') {
        console.log(12)
    } else if (a == 'Wednesday') {
        console.log(14)
    } else if (a == 'Thursday') {
        console.log(14)
    } else if (a == 'Friday') {
        console.log(12)
    } else if (a == 'Saturday') {
        console.log(16)
    } else {
        console.log(16)
    }
}
solve("Monday")
solve("Friday")
solve("Sunday")