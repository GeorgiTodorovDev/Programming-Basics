function solve(a1, a2, a3, a4, a5) {
    let chrysanthemum = Number(a1)
    let roses = Number(a2)
    let tulips = Number(a3)
    let season = String(a4)
    let holiday = String(a5)
    let sum = 0;
    if (season == 'Spring' || season == 'Summer') {
        sum = chrysanthemum * 2 + roses * 4.1 + tulips * 2.5
        if (holiday == 'Y') {
            sum *= 1.15
        } else {
            sum = sum
        }
        if (tulips > 7 && season == 'Spring') {
            sum *= 0.95
        }
        if (tulips + roses + chrysanthemum > 20) {
            sum *= 0.8
        }
    } else if (season == 'Winter' || season == 'Autumn') {
        sum = chrysanthemum * 3.75 + roses * 4.5 + tulips * 4.15
        if (holiday == 'Y') {
            sum *= 1.15
        } else {
            sum = sum
        }
        if (roses >= 10 && season == 'Winter') {
            sum *= 0.9
        }
        if (tulips + roses + chrysanthemum > 20) {
            sum *= 0.8
        }
    }
    console.log(`${(sum + 2).toFixed(2)}`)
}
solve(2, 4, 8, 'Spring', 'Y')
solve(3, 10, 9, 'Winter', 'N')
solve(10, 10, 10, 'Autumn', 'N')