function solve(a1, a2, a3) {
    let budget = Number(a1);
    let cat = String(a2);
    let ppl = Number(a3);
    let ticket = 0.0;
    let sum = 0.0;
    if (cat == 'VIP') {
        ticket = 499.99;
    } else if (cat == 'Normal') {
        ticket = 249.99;
    }
    if (1 <= ppl && ppl <= 4) {
        budget *= 0.25;
        sum = ppl * ticket;
    } else if (5 <= ppl && ppl <= 9) {
        budget *= 0.4;
        sum = ppl * ticket;
    } else if (10 <= ppl && ppl <= 24) {
        budget *= 0.5;
        sum = ppl * ticket;
    } else if (25 <= ppl && ppl <= 49) {
        budget *= 0.6;
        sum = ppl * ticket;
    } else {
        budget *= 0.75;
        sum = ppl * ticket;
    }
    if (budget >= sum) {
        console.log(`Yes! You have ${Math.abs(budget - sum).toFixed(2)} leva left.`)
    } else {
        console.log(`Not enough money! You need ${Math.abs(budget - sum).toFixed(2)} leva.`)
    }
}
solve(1000, 'Normal', 1)
solve(30000, 'VIP', 49)