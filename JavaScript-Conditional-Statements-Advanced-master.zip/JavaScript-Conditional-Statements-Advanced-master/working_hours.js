function solve(a1, a2) {
    let num = Number(a1);
    let day = String(a2);
    if (day == 'Monday' || day == 'Tuesday' || day == 'Wednesday' || day == 'Thursday' ||
    day == 'Friday' || day == 'Saturday') {
        if (num >= 10 && num <= 18) {
            console.log("open");
        } else {
            console.log('closed');
        }
    } else {
        console.log('closed')
    }
}
solve(11, 'Monday')
solve(19, 'Friday')
solve(11, 'Sunday')