function fishingBoat(buget, sezon, numFishmen){

    buget = Number(buget);
    numFishmen = Number(numFishmen);
    let priceBoat = 0;
    let discount = 0;

    switch(sezon){
        case 'Spring' :
            priceBoat = 3000;
            break;
        case 'Summer' :
        case 'Autumn' :
            priceBoat = 4200;
            break;
        case 'Winter' :
            priceBoat = 2600;
            break;
    }

    if(numFishmen <= 6){
        discount = priceBoat * 0.90;
    } else if(numFishmen >= 7 && numFishmen <= 11){
        discount = priceBoat * 0.85;
    } else if(numFishmen >= 12){
        discount = priceBoat * 0.75;
    }

    if(numFishmen % 2 == 0 && sezon !== 'Autumn'){
        discount = discount * 0.95;
    }

    if(buget >= discount){
        console.log(`Yes! You have ${(buget - discount).toFixed(2)} leva left.`);
    }else if(buget < discount){
        console.log(`Not enough money! You need ${(Math.abs(discount - buget)).toFixed(2)} leva.`);
    }
}
fishingBoat(3000, 'Summer', 11)
fishingBoat(3600, 'Autumn', 6)
fishingBoat(2000, 'Winter', 13)