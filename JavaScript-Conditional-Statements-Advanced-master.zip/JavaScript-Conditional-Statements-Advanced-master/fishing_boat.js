function solve(a1, a2, a3) {
    let budget = Number(a1);
    let season = String(a2);
    let fishermen = Number(a3);
    let rent = 0;
    let disc = 0;
    if (season == 'Spring') {
        rent = 3000;
    } else if (season == 'Summer' || season == 'Autumn') {
        rent = 4200;
    } else {
        rent = 2600;
    }
    if (fishermen <= 6) {
        disc = 0.9 * rent;
    } else if (fishermen >= 7 && fishermen <= 11) {
        disc = 0.85 * rent;
    } else {
        disc = 0.75 * rent;
    }
    if (fishermen % 2 == 0 && season != 'Autumn') {
        disc *= 0.95;
    }
    if (budget >= disc) {
        console.log(`Yes! You have ${Math.abs(budget - disc).toFixed(2)} leva left.`)
    } else {
        console.log(`Not enough money! You need ${Math.abs(budget - disc).toFixed(2)} leva.`)
    }
}
solve(3000, 'Summer', 11)
solve(3600, 'Autumn', 6)
solve(2000, 'Winter', 13)