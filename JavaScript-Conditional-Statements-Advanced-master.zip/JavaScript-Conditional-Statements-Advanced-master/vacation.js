function solve(a1, a2) {
    let budget = Number(a1)
    let season = String(a2)
    let location = ""
    let room = ""
    if (budget <= 1000 && season == 'Summer') {
        room = "Camp"
        location = 'Alaska'
        budget *= 0.65
    } else if (budget <= 1000 && season == 'Winter') {
        room = 'Camp'
        location = 'Morocco'
        budget *= 0.45
    }
    if (1000 < budget && budget <= 3000 && season == 'Summer') {
        room = 'Hut'
        location = 'Alaska'
        budget *= 0.8
    } else if (1000 < budget && budget <= 3000 && season == 'Winter') {
        room = 'Hut'
        location = 'Morocco'
        budget *= 0.6
    }
    if (budget > 3000 && season == 'Summer') {
        room = 'Hotel'
        location = 'Alaska'
        budget *= 0.9
    } else if (budget > 3000 && season == 'Winter') {
        room = 'Hotel'
        location = 'Morocco'
        budget *= 0.9
    }
    console.log(`${location} - ${room} - ${budget.toFixed(2)}`)
}
solve(800, 'Summer')
solve(799.5, 'Winter')
solve(3460, 'Summer')
solve(1100, 'Summer')
solve(5000, 'Winter')
solve(2543.99, 'Winter')