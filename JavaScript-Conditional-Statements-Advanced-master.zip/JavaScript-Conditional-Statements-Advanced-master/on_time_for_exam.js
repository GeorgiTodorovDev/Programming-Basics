function solve(a1, a2, a3, a4) {
    let hrsExam = Number(a1);
    let minExam = Number(a2);
    let hrsArr = Number(a3);
    let minArr = Number(a4);

    let examTtl = hrsExam * 60 + minExam;
    let arrTll = hrsArr * 60 + minArr;

    let diff = Math.abs(examTtl - arrTll);

    if (arrTll > examTtl) {
        console.log("Late");
    } else if (examTtl - arrTll <= 30) {
        console.log("On time");
    } else {
        console.log("Early");
    }
    if (examTtl - arrTll > 0) {
        if (diff < 60) {
            console.log(`${diff} minutes before the start`);
        } else {
            if (diff % 60 < 10) {
                console.log(`${Math.floor(diff / 60)}:0${(diff % 60)} hours before the start`);
            } else {
                console.log(`${Math.floor(diff / 60)}:${(diff % 60)} hours before the start`);
            }
        }
    } else if (arrTll - examTtl > 0) {
        if (diff < 60) {
            console.log(`${diff} minutes after the start`);
        } else {
            if (diff % 60 < 10) {
                console.log(`${Math.floor(diff / 60)}:0${(diff % 60)} hours after the start`);
            } else {
                console.log(`${Math.floor(diff / 60)}:${(diff % 60)} hours after the start`);
            }
        }
    }  
}
solve(9, 30, 9, 50)
solve(9, 00, 8, 30)
solve(16, 00, 15, 00)
solve(9, 00, 10, 30)
solve(14, 00, 13, 55)
solve(11, 30, 8, 12)
solve(10, 00, 10, 00)
solve(11, 30, 10, 55)
solve(11, 30, 12, 29)