function solve(input){
    let budget = Number(input.shift());
    let sex = input.shift();
    let age = Number(input.shift());
    let sport = input.shift();
    let sum = 0;

    if (sex === "m"){
        if (sport === "Gym") {
            sum = 42;
            if (age <= 19) {
                sum *= 0.80;
            }
        } else if (sport === "Boxing") {
            sum = 41;
            if (age <= 19) {
                sum *= 0.8;
            }
        } else if (sport === "Yoga") {
            sum = 45;
            if ( age <=19) {
                sum *= 0.8;
            }
        } else if (sport === "Zumba") {
            sum = 34;
            if (age <= 19) {
                sum *= 0.8; 
            }
        } else if (sport === "Dances") {
            sum = 51;
            if (age <= 19) {
                cardPrice = cardPrice * 0.80;
            }
        } else if (sport === "Pilates") {
            sum = 39;
            if (age <= 19) {
                sum *= 0.8;
            }
        }
    } else if (sex === "f") {
        if (sport === "Gym") {
            sum = 35;
            if (age <= 19) {
                sum *= 0.8;
            }
        } else if (sport === "Boxing") {
            sum = 37;
            if (age <= 19) {
                sum *= 0.8;
            }
        } else if (sport === "Yoga") {
            sum = 42;
            if ( age <=19) {
                sum *= 0.8;
            }
        } else if (sport === "Zumba") {
            sum = 31;
            if (age <= 19) {
                sum *= 0.8; 
            }
        } else if ( port === "Dances") {
            sum = 53;
            if (age <= 19) {
                sum *= 0.8;
            }
        } else if (sport === "Pilates") {
            sum = 37;
            if (age <= 19) {
                sum *= 0.8;
            }
        }
        
    }
    if (budget >= sum) {
        console.log(`You purchased a 1 month pass for ${sport}.`)
    } else {
        let difference = sum - budget;
        console.log(`You don't have enough money! You need $${difference.toFixed(2)} more.`)
    }
}
solve(50, 'm', 23, 'Gym')
solve(20, 'f', 15, 'Yoga')
solve(10, 'm', 50, 'Pilates')
