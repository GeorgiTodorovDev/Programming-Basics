function solve(input) {
    let fruit = input.shift();
    let sizeSet = input.shift();
    let numSet = Number(input.shift());
    let sum = 0;
    if (fruit == 'Watermelon') {
        if (sizeSet == 'small') {
            sum = 2 * 56 * numSet;
            if (400 <= sum && sum <= 1000) {
                sum *= 0.85;
            } else if (sum > 1000) {
                sum *= 0.5;
            }
        } else if (sizeSet == 'big') {
            sum = 5 * 28.7 * numSet;
            if (400 <= sum && sum <= 1000) {
                sum *= 0.85;
            } else if (sum > 1000) {
                sum *= 0.5;
            }
        }
    } else if (fruit == 'Mango') {
        if (sizeSet == 'small') {
            sum = 2 * 36.66 * numSet;
            if (400 <= sum && sum <= 1000) {
                sum *= 0.85;
            } else if (sum > 1000) {
                sum *= 0.5;
            }
        } else if (sizeSet == 'big') {
            sum = 5 * 19.6 * numSet;
            if (400 <= sum && sum <= 1000) {
                sum *= 0.85;
            } else if (sum > 1000) {
                sum *= 0.5;
            }
        }
    } else if (fruit == 'Pineapple') {
        if (sizeSet == 'small') {
            sum = 2 * 42.1 * numSet;
            if (400 <= sum && sum <= 1000) {
                sum *= 0.85;
            } else if (sum > 1000) {
                sum *= 0.5;
            }
        } else if (sizeSet == 'big') {
            sum = 5 * 24.8 * numSet;
            if (400 <= sum && sum <= 1000) {
                sum *= 0.85;
            } else if (sum > 1000) {
                sum *= 0.5;
            }
        }
    } else if (fruit == 'Raspberry') {
        if (sizeSet == 'small') {
            sum = 2 * 20 * numSet;
            if (400 <= sum && sum <= 1000) {
                sum *= 0.85;
            } else if (sum > 1000) {
                sum *= 0.5;
            }
        } else if (sizeSet == 'big') {
            sum = 5 * 15.2 * numSet;
            if (400 <= sum && sum <= 1000) {
                sum *= 0.85;
            } else if (sum > 1000) {
                sum *= 0.5;
            }
        }
    }
    console.log(`${sum.toFixed(2)} lv.`)
}
solve('Watermelon', 'big', 4)
solve('Pineapple', 'small', 1)
solve('Raspberry', 'small', 50)
solve('Mango', 'big', 8)