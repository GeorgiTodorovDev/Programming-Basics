function solve(input) {
    let bitcoin = Number(input.shift());
    let yuan = Number(input.shift());
    let commision = Number(input.shift());
    let oneBC = 1168; //lv
    let oneYuan = 0.15; //dollar
    let usd = 1.76; //lv
    let euro = 1.95; //lv
    let BC = bitcoin * oneBC;
    let Y = yuan * oneYuan;
    let Y2 = Y * usd;
    let ttl = (BC + Y2) / euro;
    let comm = ttl * commision / 100;
    let sum = ttl - comm;
    console.log(sum.toFixed(2));
}
solve([1, 5, 5]);
solve([20, 5678, 2.4]);
solve([7, 50200.12, 3])
