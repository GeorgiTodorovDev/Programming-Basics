function solve(input) {
    let minPerDays = Number(input.shift());
    let numWalks = Number(input.shift());
    let cal = Number(input.shift());
    let walks = minPerDays * numWalks;
    let ttlCal = walks * 5;
    let halfCal = cal * 50 / 100;
    if (ttlCal >= halfCal) {
        console.log(`Yes, the walk for your cat is enough. Burned calories per day: ${ttlCal}.`);
    } else {
        console.log(`No, the walk for your cat is not enough. Burned calories per day: ${ttlCal}.`);
    }
}
solve([30, 3, 600]);
solve([15, 2, 500]);
solve([40, 2, 300]);