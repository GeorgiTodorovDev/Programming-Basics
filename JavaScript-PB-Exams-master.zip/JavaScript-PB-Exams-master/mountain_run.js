function solve(input) {
    let recInSec = Number(input.shift());
    let dist = Number(input.shift());
    let timeInSec = Number(input.shift());
    let ttlDist = dist * timeInSec;
    let ttlTime = Math.floor((dist / 50)) * 30;
    let Time = (ttlDist + ttlTime).toFixed(2);
    let delay = (Time - recInSec).toFixed(2);
    if (Time < recInSec) {
       console.log(`Yes! The new record is ${Time} seconds.`);
    } else {
        console.log(`No! He was ${delay} seconds slower.`);
    }
    
}
solve([10164, 1400, 25]);
solve([5554.36, 1340, 3.23]);
solve([1377, 389, 3]);