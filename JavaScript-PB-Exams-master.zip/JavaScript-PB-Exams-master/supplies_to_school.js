function solve(input) {
    let numPens = Number(input.shift());
    let numMarkers = Number(input.shift());
    let detergent = Number(input.shift());
    let discount = Number(input.shift());
    let pens = numPens * 5.8;
    let markers = numMarkers * 7.2;
    let deter = detergent * 1.2;
    let sum = pens + markers + deter;
    let disc = sum - (sum * discount / 100);
    console.log(disc.toFixed(3));
}
solve([2, 3, 2.5, 25]);
solve([4, 2, 5, 13]);
solve([7, 8, 0.5, 45]);