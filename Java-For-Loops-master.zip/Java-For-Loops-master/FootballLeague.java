package ForLoops;

import java.util.Scanner;

public class FootballLeague {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int capacity = Integer.parseInt(scanner.nextLine());
        int ttlFans = Integer.parseInt(scanner.nextLine());
        double a = 0;
        double b = 0;
        double v = 0;
        double g = 0;
        for (int i = 1; i <= ttlFans; i++) {
            String sector = scanner.nextLine();
            if (sector.equals("A")) {
                a++;
            } else if (sector.equals("B")) {
                b++;
            } else if (sector.equals("V")) {
                v++;
            } else if (sector.equals("G")) {
                g++;
            }
        }
        double sectorA = a / ttlFans * 100;
        double sectorB = b / ttlFans * 100;
        double sectorV = v / ttlFans * 100;
        double sectorG = g / ttlFans * 100;
        double fans = (a + b + v + g) / capacity * 100;
        System.out.printf("%.2f%%%n", sectorA);
        System.out.printf("%.2f%%%n", sectorB);
        System.out.printf("%.2f%%%n", sectorV);
        System.out.printf("%.2f%%%n", sectorG);
        System.out.printf("%.2f%%", fans);
    }
}
