package ForLoops;

import java.util.Scanner;

public class Bills {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int months = Integer.parseInt(scanner.nextLine());
        double elecBill = 0;
        double netBill = 0;
        double waterBill = 0;
        double othersBill = 0;
        for (int i = 1; i <= months; i++) {
            double elec = Double.parseDouble(scanner.nextLine());
            elecBill += elec;
            netBill = 15 * months;
            waterBill = 20 * months;
            othersBill = (elecBill + netBill + waterBill) * 1.2;
        }
        double avr = (elecBill + netBill + waterBill + othersBill) / months;
        System.out.printf("Electricity: %.2f lv%n", elecBill);
        System.out.printf("Water: %.2f lv%n", waterBill);
        System.out.printf("Internet: %.2f lv%n", netBill);
        System.out.printf("Other: %.2f lv%n", othersBill);
        System.out.printf("Average: %.2f lv", avr);
    }
}
