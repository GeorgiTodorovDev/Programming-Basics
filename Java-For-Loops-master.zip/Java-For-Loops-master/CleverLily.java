package ForLoops;

import java.util.Scanner;

public class CleverLily {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int age = Integer.parseInt(scanner.nextLine());
        double washMachine = Double.parseDouble(scanner.nextLine());
        int pricePerToy = Integer.parseInt(scanner.nextLine());
        int sumOdd = 0;
        double moneyPerYear = 0;
        double sumMoney = 0;
        for (int i = 1; i <= age; i++) {
            if (i % 2 != 0) {
                sumOdd++;
            } else {
                moneyPerYear = moneyPerYear + 10;
                sumMoney += moneyPerYear - 1;
            }
        }
        double sumToys = sumOdd * pricePerToy;
        double allMoney = sumToys + sumMoney;
        if (allMoney >= washMachine) {
            System.out.printf("Yes! %.2f", Math.abs(allMoney - washMachine));
        } else {
            System.out.printf("No! %.2f", Math.abs(allMoney - washMachine));
        }
    }
}
