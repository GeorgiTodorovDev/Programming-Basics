package ForLoops;

import java.util.Scanner;

public class Logistics {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int cargo = Integer.parseInt(scanner.nextLine());
        double sumBus = 0;
        double sumTruck = 0;
        double sumTrain = 0;
        double ttlTonnage = 0;
        for (int i = 1; i <= cargo; i++) {
            int tonnage = Integer.parseInt(scanner.nextLine());
            ttlTonnage += tonnage;
            if (tonnage <= 3) {
                sumBus += tonnage;
            } else if (tonnage <= 11) {
                sumTruck += tonnage;
            } else {
                sumTrain += tonnage;
            }
        }
        double avr = (sumBus * 200 + sumTruck * 175 + sumTrain * 120) / ttlTonnage;
        double ttlsumBus = sumBus / ttlTonnage * 100;
        double ttlsumTruck = sumTruck / ttlTonnage * 100;
        double ttlsumTrain = sumTrain / ttlTonnage * 100;
        System.out.printf("%.2f%n", avr);
        System.out.printf("%.2f%%%n", ttlsumBus);
        System.out.printf("%.2f%%%n", ttlsumTruck);
        System.out.printf("%.2f%%", ttlsumTrain);
    }
}
