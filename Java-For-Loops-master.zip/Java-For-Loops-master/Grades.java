package ForLoops;

import java.util.Scanner;

public class Grades {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int students = Integer.parseInt(scanner.nextLine());
        double g1 = 0;
        double g2 = 0;
        double g3 = 0;
        double g4 = 0;
        double avr = 0;
        for (int i = 1; i <= students; i++) {
            double grade = Double.parseDouble(scanner.nextLine());
            if (grade < 3) {
                g1++;
            } else if (grade < 4) {
                g2++;
            } else if (grade < 5) {
                g3++;
            } else {
                g4++;
            }
            avr += grade / students;
        }
        double gg1 = g1 / students * 100;
        double gg2 = g2 / students * 100;
        double gg3 = g3 / students * 100;
        double gg4 = g4 / students * 100;
        System.out.printf("Top students: %.2f%%%n", gg4);
        System.out.printf("Between 4.00 and 4.99: %.2f%%%n", gg3);
        System.out.printf("Between 3.00 and 3.99: %.2f%%%n", gg2);
        System.out.printf("Fail: %.2f%%%n", gg1);
        System.out.printf("Average: %.2f", avr);
    }
}
