package ForLoops;

import java.util.Scanner;

public class GameOfIntervals {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int moves = Integer.parseInt(scanner.nextLine());
        double points = 0;
        double p1 = 0;
        double p2 = 0;
        double p3 = 0;
        double p4 = 0;
        double p5 = 0;
        double p6 = 0;
        int ttl = 0;
        for (int i = 1; i <= moves; i++) {
            int num = Integer.parseInt(scanner.nextLine());
            if (0 <= num && num <= 9) {
                points += num * 0.2;
                p1++;
            } else if (10 <= num && num <= 19) {
                points += num * 0.3;
                p2++;
            } else if (20 <= num && num <= 29) {
                points += num * 0.4;
                p3++;
            } else if (30 <= num && num <= 39) {
                p4++;
                points += 50;
            } else if (40 <= num && num <= 50) {
                p5++;
                points += 100;
            } else {
                p6++;
                points /= 2;
            }
        }
        System.out.printf("%.2f%n", points);
        System.out.printf("From 0 to 9: %.2f%%%n", p1 / moves * 100);
        System.out.printf("From 10 to 19: %.2f%%%n", p2 / moves * 100);
        System.out.printf("From 20 to 29: %.2f%%%n", p3 / moves * 100);
        System.out.printf("From 30 to 39: %.2f%%%n", p4 / moves * 100);
        System.out.printf("From 40 to 50: %.2f%%%n", p5 / moves * 100);
        System.out.printf("Invalid numbers: %.2f%%", p6 / moves * 100);
    }
}
