package ForLoops;

import java.util.Scanner;

public class Hospital {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int period = Integer.parseInt(scanner.nextLine());
        int treated = 0;
        int untreated = 0;
        int doctors = 7;
        for (int i = 1; i <= period; i++) {
            int patient = Integer.parseInt(scanner.nextLine());
            if (i % 3 == 0 && untreated > treated) {
                doctors++;
            }
            if (patient > doctors) {
                untreated += patient - doctors;
                treated += doctors;
            } else {
                treated += patient;
            }
        }
        System.out.printf("Treated patients: %d.%n", treated);
        System.out.printf("Untreated patients: %d.%n", untreated);
    }
}
