usd = float(input())
bgn = usd * 1.79549
print(round(bgn, 2))