number_of_pages = int(input())
pages = int(input())
days = int(input())
time = number_of_pages / pages
sum = time / days
print(sum)