name = input()
print('Hello, ' + name + '!')

name = input()
print(f'Hello, {name}!')