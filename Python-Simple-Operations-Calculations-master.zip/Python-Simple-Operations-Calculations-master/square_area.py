a = int(input())
size = a * a
print(size)
