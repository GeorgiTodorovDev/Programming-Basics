b1 = float(input())
b2 = float(input())
h = float(input())
sum = (b1 + b2) * h / 2
print(f'{sum:.2f}')