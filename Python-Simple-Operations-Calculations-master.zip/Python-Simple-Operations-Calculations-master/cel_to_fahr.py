a = float(input())
b = a * 9 / 5 + 32
print(f'{b:.2f}')