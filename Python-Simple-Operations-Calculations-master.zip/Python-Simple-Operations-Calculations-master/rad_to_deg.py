from math import pi
rad = float(input())
deg = rad * 180 / pi
print(round(deg))
from math import pi
rad = float(input())
deg = rad * 180 / pi
print(round(deg))
from math import pi
rad = float(input())
deg = rad * 180 / pi
print(round(deg))
from math import pi
rad = float(input())
deg = rad * 180 / pi
print(round(deg))
