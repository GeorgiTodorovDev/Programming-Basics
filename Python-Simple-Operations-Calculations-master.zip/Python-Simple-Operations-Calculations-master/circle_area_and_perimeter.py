from math import pi
r = float(input())
area = pi * pow(r, 2)
peri = pi * r * 2
print(f'{area:.2f}')
print(f'{peri:.2f}')