x = float(input())
h = float(input())
sum = x * h / 2
print(f'{sum:.2f}')