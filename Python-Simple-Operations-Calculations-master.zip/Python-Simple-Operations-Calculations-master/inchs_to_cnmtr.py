inches = float(input())
cantimeters = inches * 2.54
print(cantimeters)
