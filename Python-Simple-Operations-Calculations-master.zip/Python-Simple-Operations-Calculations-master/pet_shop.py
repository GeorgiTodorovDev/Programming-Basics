number1 = int(input())
number2 = int(input())
sum1 = number1 * 2.5 + number2 * 4
print(f"{sum1:.2f} lv.")
