a = int(input())
b = int(input())
area = a * b
print(area)