rent = int(input())
cake = rent * 0.2
drinks = cake - cake * 45 / 100
animator = rent / 3
sum = rent + cake + drinks + animator
print(sum)

