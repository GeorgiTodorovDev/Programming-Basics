name = input()
number = int(input())
hours = number * 3
print(f'The architect {name} will need {hours} hours to complete {number} project/s.')