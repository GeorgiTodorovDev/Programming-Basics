function solve(num1, num2, num3, num4) {
    let x1 = Number(num1);
    let y1 = Number(num2);
    let x2 = Number(num3);
    let y2 = Number(num4);
    let x = Math.abs(x1 - x2);
    let y = Math.abs(y1 - y2);
    let area = x * y;
    let peri =  2 * (x + y);
    console.log(area.toFixed(2));
    console.log(peri.toFixed(2));

}
solve(60, 20, 10, 50);
solve(30, 40, 70, -10);
solve(600.25, 500.75, 100.50, -200.5);