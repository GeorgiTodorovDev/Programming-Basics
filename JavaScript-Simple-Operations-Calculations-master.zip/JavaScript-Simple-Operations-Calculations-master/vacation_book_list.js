function solve(numberPages, pages, days) {
    let a = Number(numberPages);
    let b = Number(pages);
    let c = Number(days);
    let sum1 = a / b;
    let sum2 = sum1 / c;
    console.log(sum2);
}
solve(212, 20, 2);
solve(432, 15, 4)