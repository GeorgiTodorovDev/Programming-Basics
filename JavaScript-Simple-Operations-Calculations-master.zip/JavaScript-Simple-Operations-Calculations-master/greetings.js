function greeting(input) {
    let name = input;
    console.log(`Hello, ${name}!`);
}
greeting("SoftUni");