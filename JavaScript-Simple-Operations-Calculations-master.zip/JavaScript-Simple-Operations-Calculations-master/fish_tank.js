function solve(l, b, h, percent) {
    //l, b, h = cm
    //1 l = 1 cubdm
    //1 cc = 0.001 l
    let v = Number(l) * Number(b) * Number(h); //cc
    let ltrs = v * 0.001;
    let perc = Number(percent * 0.01);
    let sum = ltrs * (1-perc);
    console.log(sum.toFixed(3));
}
solve(85, 75, 47, 17);
solve(105, 77, 89, 18.5)