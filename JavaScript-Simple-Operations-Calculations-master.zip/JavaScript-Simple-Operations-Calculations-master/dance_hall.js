function solve(num1, num2, num3) {
    let l = Number(num1); //m
    let w = Number(num2); //m
    let a = Number(num3); //m
    let hallArea = (l * 100) * (w * 100);
    let wardrobe = Math.pow((a * 100), 2);
    let brench = hallArea / 10;
    let freeArea = hallArea - wardrobe - brench;
    let dancers = freeArea / (40 + 7000);
    console.log(Math.floor(dancers));
}
solve(50, 25, 2);
