function solve(n1, n2, n3, n4, n5) {
    let cenaSkum = Number(n1);
    let cenaCaca = Number(n2);
    let kgPalamud = Number(n3);
    let kgSafrid = Number(n4);
    let kgMidi = Number(n5);
    let cenaPalamud = cenaSkum + cenaSkum * 0.6;
    let cenaSafrid = cenaCaca + cenaCaca * 0.8;
    let cenaMidi = 7.5;
    let palamud = cenaPalamud * kgPalamud;
    let safrid = cenaSafrid * kgSafrid;
    let midi = cenaMidi * kgMidi;
    let ttl = palamud + safrid + midi;
    console.log(ttl.toFixed(2));

}
solve(6.9, 4.2, 1.5, 2.5, 1);
solve(5.55, 3.57, 4.3, 3.6, 7);