function solve(num1, num2) {
    let a = Number(num1);
    let b = Number(num2);
    let area = a * b;
    console.log(area);
}
solve(12, 5);