function solve(inches) {
    inches = Number(inches);
    let cm = inches * 2.54
    console.log(cm);
}
solve("5");
