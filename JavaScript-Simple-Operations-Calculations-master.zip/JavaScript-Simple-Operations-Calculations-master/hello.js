function hello() {
    console.log('Hello SoftUni');
}

hello()