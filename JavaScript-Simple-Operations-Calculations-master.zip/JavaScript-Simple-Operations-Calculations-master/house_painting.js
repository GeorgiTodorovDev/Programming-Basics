function solve(n1, n2, n3) {
    let x = Number(n1);
    let y = Number(n2);
    let h = Number(n3);
    let green = 3.4;
    let red = 4.3;
    //frontback
    let frontback = 2 * Math.pow(x, 2);
    let door = 1.2 * 2;
    //sides
    let sides = 2 * (x * y);
    //windows
    let windows = 2 * Math.pow(1.5, 2);
    //roof
    let rSides = 2 * (x * y);
    let rFrontend = 2 * ((x * h) / 2);
    //paint
    let walls = (frontback - door + sides - windows) / green;
    let roof = (rSides + rFrontend) / red;
    console.log(walls.toFixed(2));
    console.log(roof.toFixed(2));

}
solve(6, 10, 5.2);
solve(10.25, 15.45, 8.88);