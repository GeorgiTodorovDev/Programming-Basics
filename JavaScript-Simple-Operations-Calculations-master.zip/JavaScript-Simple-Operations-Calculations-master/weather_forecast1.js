function solve(n1) {
    let name = String(n1);
    if (name == "sunny") {
        console.log("It's warm outside!");
    } else {
        console.log("It's cold outside!");
    }
}
solve("sunny");
solve("cloudy");
solve("snowy");
