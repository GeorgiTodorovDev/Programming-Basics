function solve(n1) {
    let r = Number(n1);
    let area = Math.PI * Math.pow(r, 2);
    let peri = Math.PI * r * 2;
    console.log(area.toFixed(2));
    console.log(peri.toFixed(2));
}
solve(3);
solve(4.5);