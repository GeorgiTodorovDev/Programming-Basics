function solve() {
    console.log((3522 + 52353) * 23 - (2336 * 501 + 23432 - 6743) * 3);
}
solve();