function solve(days, pastryCook, cakes, waffles, pancakes) {
    let cake = 45
    let waffle = 5.80
    let pancake = 3.20
    let ttlCakes = Number(cakes) * cake;
    let ttlWaffles = Number(waffles) * waffle;
    let ttlPancackes = Number(pancakes) * pancake;
    let ttlPerDay = (ttlCakes + ttlWaffles + ttlPancackes) * pastryCook;
    let ttlCampaign = ttlPerDay * days;
    let grantTotal = ttlCampaign - ttlCampaign / 8;
    console.log(grantTotal.toFixed(2));
}
solve(23, 8 ,14, 30, 16);
solve(131, 5, 9, 33, 46);