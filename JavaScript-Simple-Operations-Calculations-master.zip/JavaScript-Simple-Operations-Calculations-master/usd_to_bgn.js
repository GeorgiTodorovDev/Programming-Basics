function sovle(bgn) {
    let usd = 1.79549
    console.log((usd * bgn).toFixed(2));

}
sovle(20);
sovle(100);
sovle(12.5);