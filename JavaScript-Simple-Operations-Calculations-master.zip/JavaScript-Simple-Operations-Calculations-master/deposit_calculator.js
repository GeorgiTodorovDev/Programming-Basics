function solve(deposit, term, interest) {
    let a = Number(deposit) * Number(interest) / 100;
    let b = Number(a) / 12;
    let c = Number(deposit) + Number(term) * Number(b);
    console.log(c);
}
solve(200, 3, 5.7);
solve(2350, 6, 7);