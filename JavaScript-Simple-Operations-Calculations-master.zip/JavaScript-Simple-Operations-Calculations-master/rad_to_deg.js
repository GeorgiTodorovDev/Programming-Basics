function solve(rad) {
    let deg = rad * 180 / Math.PI;
    console.log(deg.toFixed(0));
}
solve(3.1416);
solve(6.2832);
solve(0.7854);
solve(0.5236);