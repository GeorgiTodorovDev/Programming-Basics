function solve(a) {
    let x = Number(a);
    let sum = a * 9 / 5 + 32;
    console.log(sum.toFixed(2));

}
solve(25);
solve(0);
solve(-5.5);
solve(32.3);
