function solve(n1 ,n2, n3, n4, n5) {
    let wiskPr = Number(n1);
    let qntBira = Number(n2);
    let qntWine = Number(n3);
    let qntRakiq = Number(n4);
    let qntWisk = Number(n5);
    let rakiqPr = wiskPr / 2;
    let winePr = rakiqPr - rakiqPr * 0.4;
    let biraPr = rakiqPr - rakiqPr * 0.8;
    let wisk = wiskPr * qntWisk;
    let bira = qntBira * biraPr;
    let wine = qntWine * winePr;
    let rakiq = rakiqPr * qntRakiq;
    let sum = wisk + bira + wine + rakiq;
    console.log(sum.toFixed(2));
}
solve(50, 10, 3.5, 6.5, 1);
solve(63.44, 3.57, 6.35, 8.15, 2.5);