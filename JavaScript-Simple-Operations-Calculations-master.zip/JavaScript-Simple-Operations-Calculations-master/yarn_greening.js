function solve(cm) {
    let oneCubMeter = 7.61;
    let discout = 0.18;
    let sum1 = cm * oneCubMeter;
    let sum2 = sum1 * discout;
    let sum3 = sum1 - sum2;
    console.log(`The final price is: ${sum3.toFixed(2)} lv.`);
    console.log(`The discount is: ${sum2.toFixed(2)} lv.`);
}
solve(550);