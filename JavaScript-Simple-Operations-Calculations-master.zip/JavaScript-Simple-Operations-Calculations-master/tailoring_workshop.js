function solve(num1, num2, num3) {
    let a = Number(num1);
    let b = Number(num2);
    let c = Number(num3);
    let raba = 30 / 100; //cm
    let cubm1 = 7; //dolara
    let cubm2 = 9; //dolara
    let usd = 1.85;
    let sum1 = a * (b + 2 * raba) * (c + 2 * raba);
    let sum2 = a * (b / 2) * (b / 2);
    let sum3 = sum1 * cubm1 + sum2 * cubm2;
    let sum4 = sum3 * usd;
    console.log(`${sum3.toFixed(2)} USD`);
    console.log(`${sum4.toFixed(2)} BGN`);

}
solve(5, 1, 0.5);
solve(10, 1.2, 0.65);
