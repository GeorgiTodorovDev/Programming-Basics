function solve(n1, n2, n3, n4) {
    let vegkg = Number(n1);
    let frutkg = Number(n2);
    let ttlvegkg = Number(n3);
    let ttlfrutkg = Number(n4);
    let euro = 1.94;
    let ttl1 = vegkg * ttlvegkg;
    let ttl2 = frutkg * ttlfrutkg;
    let ttl3 = ttl1 + ttl2;
    let ttl4 = ttl3 / euro;
    console.log(ttl4.toFixed(2));

}
solve(0.194, 19.4, 10, 10);
solve(1.5, 2.5, 10, 10);