function halobalo(strwPrice, qntyBan, qntyOran, qntyRasp, qntyStrw) {
    let raspPrice = Number(strwPrice) / 2;
    let oranPrice = Number(raspPrice) - Number(raspPrice) * 40 / 100;
    let bananPrice = Number(raspPrice) - Number(raspPrice) * 80 / 100;
    let sum1 = Number(strwPrice) * Number(qntyStrw);
    let sum2 = Number(qntyBan) * Number(bananPrice);
    let sum3 = Number(qntyOran) * Number(oranPrice);
    let sum4 = Number(qntyRasp) * Number(raspPrice);
    console.log(sum1 + sum2 + sum3 + sum4);


}
halobalo(48, 10, 3.3, 6.5, 1.7);
halobalo(63.5, 3.57, 6.35, 8.15, 2.5);