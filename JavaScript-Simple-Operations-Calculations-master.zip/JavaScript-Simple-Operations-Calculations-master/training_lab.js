function solve(n1, n2) {

    let l = Number(n1);
    let w = Number(n2);
    let L = l * 100; //cm
    let W = w * 100; //cm
    let l1 = 70;
    let w1 = 120;
    let corridor = 100;
    let sum1 = Math.floor(L / 120);
    let sum2 = Math.floor((W - 100) / 70);
    let sum3 = sum1 * sum2 - 3;
    console.log(sum3);
}
solve(15, 8.9);
solve(8.4, 5.2);
