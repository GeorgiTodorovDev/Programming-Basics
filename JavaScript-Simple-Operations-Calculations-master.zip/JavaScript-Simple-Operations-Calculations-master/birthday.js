function solve(rent) {
    // cake - 20% than rent
    // drinks - 45% less than cake
    // animator - 1/3 than rent
    let cake = Number(rent) * 0.2;
    let drinks = Number(cake) - Number(cake) * 45 / 100;
    let animator = Number(rent) / 3;
    let sum = Number(rent) + Number(cake) + Number(drinks) + Number(animator);
    console.log(sum);

}
solve(2250);
solve(3720);