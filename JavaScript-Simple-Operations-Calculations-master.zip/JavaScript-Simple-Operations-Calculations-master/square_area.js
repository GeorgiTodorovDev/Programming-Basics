function solve(input) {
    let a = Number(input);
    let area = a * a;
    console.log(area);
}

solve("5");