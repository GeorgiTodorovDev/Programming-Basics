function solve(n1, n2, n3) {
    let b1 = Number(n1);
    let b2 = Number(n2);
    let h = Number(n3);
    let sum = (b1 + b2) *h / 2;
    console.log(sum.toFixed(2));
}
solve(8, 13, 7);