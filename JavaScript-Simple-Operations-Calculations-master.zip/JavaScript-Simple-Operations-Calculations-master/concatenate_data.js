function solve(firstName, lastName, age, town) {
    console.log(`You are ${firstName} ${lastName}, a ${age}-years old person from ${town}.`);
    
}
solve("Maria", "Ivanova", 20, "Sofia")