function solve(n1, n2) {
    let x = Number(n1);
    let h = Number(n2);
    let sum = x * h / 2;
    console.log(sum.toFixed(2));
}
solve(20, 30);
solve(15, 35);
solve(7.75, 8.45);
solve(1.23456, 4.56789);