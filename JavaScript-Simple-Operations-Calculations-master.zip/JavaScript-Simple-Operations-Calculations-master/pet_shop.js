function solve(dogs, animals) {
    let dogFood = dogs * 2.5;
    let animalFood = animals * 4;
    let sum = dogFood + animalFood;
    console.log(`${sum.toFixed(2)} lv.`);
}
solve(13, 9);