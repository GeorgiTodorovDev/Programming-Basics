package Conditional_Statements;

import java.util.Scanner;

public class Time15Minutes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n1 = Integer.parseInt(scanner.nextLine());
        int n2 = Integer.parseInt(scanner.nextLine());
        int hrs = n1 * 60; //min
        int ttl = n2 + hrs + 15; //min
        int hr = ttl / 60;
        if (hr == 24){
            hr = 0;
        }
        int min = ttl % 60;
        if (min < 10) {
            System.out.printf("%d:0%d", hr, min);
        } else {
            System.out.printf("%d:%d", hr, min);
        }
    }
}
