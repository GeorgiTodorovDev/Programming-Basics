package Conditional_Statements;

import java.util.Scanner;

public class FuelTank2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String fuel = scanner.nextLine();
        double qnty = Double.parseDouble(scanner.nextLine());
        String card = scanner.nextLine();

        switch (fuel) {
            case "Gas":
                if (qnty >= 20 && qnty <= 25) {
                    if (card.equals("Yes")) {
                        double sum = qnty * (0.93 - 0.08);
                        double ttl = sum - sum * 0.08;
                        System.out.printf("%.2f lv.", ttl);
                    } else if (card.equals("No")) {
                        double sum = qnty * 0.93;
                        double disc = sum - sum * 0.08;
                        System.out.printf("%.2f lv.", disc);
                    }
                } else if (qnty > 25) {
                    if (card.equals("Yes")) {
                        double sum = qnty * (0.93 - 0.08);
                        double ttl = sum - sum * 0.1;
                        System.out.printf("%.2f lv.", ttl);
                    } else if (card.equals("No")) {
                        double sum = qnty * 0.93;
                        double disc = sum - sum * 0.1;
                        System.out.printf("%.2f lv.", disc);
                    }
                } else {
                    if (card.equals("Yes")) {
                        double sum = qnty * (0.93 - 0.08);
                        System.out.printf("%.2f lv.", sum);
                    } else if (card.equals("No")) {
                        double sum = qnty * 0.93;
                        System.out.printf("%.2f lv.", sum);
                    }
                }
                break;
            case "Gasoline":
                if (qnty >= 20 && qnty <= 25) {
                    if (card.equals("Yes")) {
                        double sum = qnty * (2.22 - 0.18);
                        double ttl = sum - sum * 0.08;
                        System.out.printf("%.2f lv.", ttl);
                    } else if (card.equals("No")) {
                        double sum = qnty * 2.22;
                        double disc = sum - sum * 0.08;
                        System.out.printf("%.2f lv.", disc);
                    }
                } else if (qnty > 25) {
                    if (card.equals("Yes")) {
                        double sum = qnty * (2.22 - 0.18);
                        double ttl = sum - sum * 0.1;
                        System.out.printf("%.2f lv.", ttl);
                    } else if (card.equals("No")) {
                        double sum = qnty * 2.22;
                        double disc = sum - sum * 0.1;
                        System.out.printf("%.2f lv.", disc);
                    }
                } else {
                    if (card.equals("Yes")) {
                        double sum = qnty * (2.22- 0.18);
                        System.out.printf("%.2f lv.", sum);
                    } else if (card.equals("No")) {
                        double sum = qnty * 2.22;
                        System.out.printf("%.2f lv.", sum);
                    }
                }
                break;
            case "Diesel":
                if (qnty >= 20 && qnty <= 25) {
                    if (card.equals("Yes")) {
                        double sum = qnty * (2.33 - 0.12);
                        double ttl = sum - sum * 0.08;
                        System.out.printf("%.2f lv.", ttl);
                    } else if (card.equals("No")) {
                        double sum = qnty * 2.33;
                        double disc = sum - sum * 0.08;
                        System.out.printf("%.2f lv.", disc);
                    }
                } else if (qnty > 25) {
                    if (card.equals("Yes")) {
                        double sum = qnty * (2.33- 0.12);
                        double ttl = sum - sum * 0.1;
                        System.out.printf("%.2f lv.", ttl);
                    } else if (card.equals("No")) {
                        double sum = qnty * 2.33;
                        double disc = sum - sum * 0.1;
                        System.out.printf("%.2f lv.", disc);
                    }
                } else {
                    if (card.equals("Yes")) {
                        double sum = qnty * (2.33 - 0.12);
                        System.out.printf("%.2f lv.", sum);
                    } else if (card.equals("No")) {
                        double sum = qnty * 2.33;
                        System.out.printf("%.2f lv.", sum);
                    }
                }
                break;
        }
    }
}
