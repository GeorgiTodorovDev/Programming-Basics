package Conditional_Statements;

import java.util.Scanner;

public class MetricConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double conv = Double.parseDouble(scanner.nextLine());
        String name = scanner.nextLine();
        String name2 = scanner.nextLine();
        if (name.equals("mm") && name2.equals("m")) {
            double a = conv / 1000;
            System.out.printf("%.3f", a);
        } else if (name.equals("mm") && name2.equals("cm")) {
            double a = conv / 10;
            System.out.printf("%.3f", a);
        }
        if (name.equals("m") && name2.equals("mm")) {
            double a = conv * 1000;
            System.out.printf("%.3f", a);
        } else if (name.equals("m") && name2.equals("cm")) {
            double a = conv * 100;
            System.out.printf("%.3f", a);
        }
        if (name.equals("cm") && name2.equals("m")) {
            double a = conv / 100;
            System.out.printf("%.3f", a);
        } else if (name.equals("cm") && name2.equals("mm")) {
            double a = conv * 10;
            System.out.printf("%.3f", a);
        }
     }
}
