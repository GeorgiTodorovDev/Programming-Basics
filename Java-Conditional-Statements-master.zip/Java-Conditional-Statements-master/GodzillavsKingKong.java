package Conditional_Statements;

import java.util.Scanner;

public class GodzillavsKingKong {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double filmBudget = Double.parseDouble(scanner.nextLine());
        int statists = Integer.parseInt(scanner.nextLine());
        double cloths = Double.parseDouble(scanner.nextLine());

        double decor = filmBudget * 0.1;
        double costCloths = statists * cloths;
        double ttlcost = decor + costCloths;
        if (statists > 150) {
            costCloths *= 0.9;
            ttlcost = decor + costCloths;
        }
        if (ttlcost > filmBudget) {
            System.out.println("Not enough money!");
            System.out.printf("Wingard needs %.2f leva more.", Math.abs(ttlcost - filmBudget));
        } else if (ttlcost <= filmBudget) {
            System.out.println("Action!");
            System.out.printf("Wingard starts filming with %.2f leva left.", Math.abs(ttlcost - filmBudget));
        }

    }
}
