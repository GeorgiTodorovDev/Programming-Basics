package Conditional_Statements;

import java.util.Scanner;

public class Scholarship {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double income = Double.parseDouble(scanner.nextLine());
        double avr = Double.parseDouble(scanner.nextLine());
        double minWorkSlr = Double.parseDouble(scanner.nextLine());

        double social = 0;
        double grade = 0;

        if (income <= minWorkSlr && avr >= 4.5) {
            social = minWorkSlr * 0.35;
        }
        if (avr >= 5.5) {
            grade = avr * 25;
        }
        if (social > grade) {
            System.out.printf("You get a Social scholarship %.0f BGN%n", Math.floor(social));
        } else if (social < grade) {
            System.out.printf("You get a scholarship for excellent results %.0f BGN", Math.floor(grade));
        } else {
            System.out.println("You cannot get a scholarship!");
        }

    }
}
