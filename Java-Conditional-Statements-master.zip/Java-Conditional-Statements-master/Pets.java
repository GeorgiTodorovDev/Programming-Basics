package Conditional_Statements;

import java.util.Scanner;

public class Pets {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int days = Integer.parseInt(scanner.nextLine());
        int foodLeft = Integer.parseInt(scanner.nextLine()); //kg
        double dogFood = Double.parseDouble(scanner.nextLine()); //kg
        double catFood = Double.parseDouble(scanner.nextLine()); //kg
        double turtleFood = Double.parseDouble(scanner.nextLine()); //gr
        double ttlFood = (days * dogFood) + (days * catFood) + (days * turtleFood / 1000); //kg
        if (ttlFood <= foodLeft) {
            double sum = Math.abs(ttlFood - foodLeft);
            System.out.printf("%.0f kilos of food left.", Math.floor(sum));
        } else {
            double sum = Math.abs(ttlFood - foodLeft);
            System.out.printf("%.0f more kilos of food are needed.", Math.ceil(sum));
        }
    }
}
