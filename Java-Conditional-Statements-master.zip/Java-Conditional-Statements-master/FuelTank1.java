package Conditional_Statements;

import java.util.Scanner;

public class FuelTank1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();
        double ltr = Double.parseDouble(scanner.nextLine());
        boolean validFuel = name.equals("Diesel") || name.equals("Gasoline") || name.equals("Gas");
        if (!validFuel) {
            System.out.println("Invalid fuel!");
        } else {
            if (ltr >= 25) {
                System.out.printf("You have enough %s.", name.toLowerCase());
            } else {
                System.out.printf("Fill your tank with %s!", name.toLowerCase());
            }
        }
    }
}
