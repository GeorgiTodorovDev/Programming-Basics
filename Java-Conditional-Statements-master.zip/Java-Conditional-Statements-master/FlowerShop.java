package Conditional_Statements;

import java.util.Scanner;

public class FlowerShop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int magnolii = Integer.parseInt(scanner.nextLine());
        int zumbuli = Integer.parseInt(scanner.nextLine());
        int rozi = Integer.parseInt(scanner.nextLine());
        int kaktusi = Integer.parseInt(scanner.nextLine());
        double giftPrice = Double.parseDouble(scanner.nextLine());
        double ttlSumFlowers = magnolii * 3.25 + zumbuli * 4 + rozi * 3.5 + kaktusi * 8;
        double danak = ttlSumFlowers * 0.05;
        double left = ttlSumFlowers - danak;
        if (left >= giftPrice) {
            double l = Math.abs(left - giftPrice);
            System.out.printf("She is left with %.0f leva.", Math.floor(l));
        } else {
            double l = Math.abs(left - giftPrice);
            System.out.printf("She will have to borrow %.0f leva.", Math.ceil(l));
        }
    }
}
