package Conditional_Statements;

import java.util.Scanner;

public class PipesInPool {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int volume = Integer.parseInt(scanner.nextLine());
        int p1 = Integer.parseInt(scanner.nextLine());
        int p2 = Integer.parseInt(scanner.nextLine());
        double h = Double.parseDouble(scanner.nextLine());

        double P1 = p1 * h;
        double P2 = p2 * h;
        double V = P1 + P2;
        if (V <= volume) {
            double V2 = (V / volume) * 100;
            double a1 = P1 / V * 100;
            double a2 = P2 / V * 100;
            char p = '%';
            System.out.printf("The pool is %.2f%s full. Pipe 1: %.2f%s. Pipe 2: %.2f%s.", V2, p, a1, p, a2, p);
        } else if (V > volume){
            System.out.printf("For %.2f hours the pool overflows with %.2f liters.", h, Math.abs(volume - V));
        }
    }
}
