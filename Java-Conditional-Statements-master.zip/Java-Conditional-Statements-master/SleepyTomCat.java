package Conditional_Statements;

import java.util.Scanner;

public class SleepyTomCat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double restDays = Integer.parseInt(scanner.nextLine());
        double ttlRest = restDays * 127; //min
        double workingDays = 365 - restDays;
        double ttlWork = workingDays * 63; //min
        double ttl = ttlRest + ttlWork;
        double diff = Math.abs(30000 - (ttlRest + ttlWork)); //min
        double diffHrs = Math.floor(diff / 60);
        double diffMins = diff % 60;
        if (ttl > 30000) {
            System.out.println("Tom will run away");
            System.out.printf("%.0f hours and %.0f minutes more for play", diffHrs, diffMins);
        } else if (ttl <= 30000) {
            System.out.println("Tom sleeps well");
            System.out.printf("%.0f hours and %.0f minutes less for play", diffHrs, diffMins);
        }
    }
}
