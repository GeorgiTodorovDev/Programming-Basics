package Conditional_Statements;

import java.util.Scanner;

public class Firm {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int hrsNeeded = Integer.parseInt(scanner.nextLine());
        int days = Integer.parseInt(scanner.nextLine());
        int workers1 = Integer.parseInt(scanner.nextLine());
        double ttlWorkingHrs = Math.floor((days - days * 0.1) * 8);
        double ttlWorkingHrs2 = Math.floor(workers1 * 2 * days);
        double ttl = ttlWorkingHrs + ttlWorkingHrs2;
        if (ttl >= hrsNeeded) {
            System.out.printf("Yes!%.0f hours left.", Math.abs(ttl - hrsNeeded));
        } else {
            System.out.printf("Not enough time!%.0f hours needed.", Math.abs(ttl - hrsNeeded));
        }
    }
}
