package Conditional_Statements;

import java.util.Scanner;

public class WorldSwimmingRecord {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double recInSec = Double.parseDouble(scanner.nextLine());
        double dist = Double.parseDouble(scanner.nextLine());
        double secForMeter = Double.parseDouble(scanner.nextLine());
        double ttlDistInSec = dist * secForMeter; //sec
        double delay = 0;
        if (dist >= 15) {
            delay = Math.floor(dist / 15) * 12.5; //sec
        }
        double ttlTime = ttlDistInSec + delay;
        if (ttlTime >= recInSec) {
            System.out.printf("No, he failed! He was %.2f seconds slower.", Math.abs(ttlTime - recInSec));
        } else if (ttlTime < recInSec) {
            System.out.printf("Yes, he succeeded! The new world record is %.2f seconds.", ttlTime);
        }
    }
}
