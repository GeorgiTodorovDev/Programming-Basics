package Conditional_Statements;

import java.util.Scanner;

public class ToyShop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double puzzle = 2.6;
        double doll = 3;
        double bear = 4.1;
        double minion = 8.2;
        double truck = 2;
        double trip = Double.parseDouble(scanner.nextLine());
        int ttlPuzzle = Integer.parseInt(scanner.nextLine());
        int ttlDolls = Integer.parseInt(scanner.nextLine());
        int ttlBears = Integer.parseInt(scanner.nextLine());
        int ttlMinions = Integer.parseInt(scanner.nextLine());
        int ttlTrucks = Integer.parseInt(scanner.nextLine());
        //ttl toys
        double sumPuzzle = puzzle * ttlPuzzle;
        double sumDolls = doll * ttlDolls;
        double sumBears = bear * ttlBears;
        double sumMinions = minion * ttlMinions;
        double sumTrucks = truck * ttlTrucks;
        double sum = sumPuzzle + sumDolls + sumBears + sumMinions + sumTrucks;
        double ttlToys = ttlPuzzle + ttlDolls + ttlBears + ttlMinions + ttlTrucks;
        if (ttlToys >= 50) { // ако е вярно
            double discount = sum * 0.25; // отстъпката е толкова
            sum -= discount; // сумата - отстъпката
        }
        double rent = sum * 0.1; // и дори if да не е вярно смятаме наема
        sum -= rent; // сумата - 10% от наема / а ако if е вярно взема сумата от if sum
        if (sum >= trip) {
            System.out.printf("Yes! %.2f lv left.", sum - trip);
        } else {
            System.out.printf("Not enough money! %.2f lv needed.", Math.abs(sum - trip)); // ако if не е вярно отг излиза отрицателен и затова намираме абсол. разлика
        }
    }
}
