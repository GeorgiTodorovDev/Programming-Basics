package Conditional_Statements;

import java.util.Scanner;

public class TransportPrice {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double km = Integer.parseInt(scanner.nextLine());
        String name = scanner.nextLine();
        double sum = 0.0;

        if (km >= 20 && km < 100) {
            sum = km * 0.09;
        } else if (km >= 100) {
            sum = km * 0.06;
        } else if (km < 20 && name.equals("day")) {
            sum = 0.7 + km * 0.79;
        } else if (km < 20 && name.equals("night")) {
            sum = 0.7 + km * 0.9;
        }
        System.out.printf("%.2f", sum);

    }
}
