package Conditional_Statements;

import java.util.Scanner;

public class ToyShop2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double puzzle = 2.6;
        double doll = 3;
        double bear = 4.1;
        double minion = 8.2;
        double truck = 2;
        double trip = Double.parseDouble(scanner.nextLine());
        int ttlPuzzle = Integer.parseInt(scanner.nextLine());
        int ttlDolls = Integer.parseInt(scanner.nextLine());
        int ttlBears = Integer.parseInt(scanner.nextLine());
        int ttlMinions = Integer.parseInt(scanner.nextLine());
        int ttlTrucks = Integer.parseInt(scanner.nextLine());
        //ttl toys
        double sumPuzzle = puzzle * ttlPuzzle;
        double sumDolls = doll * ttlDolls;
        double sumBears = bear * ttlBears;
        double sumMinions = minion * ttlMinions;
        double sumTrucks = truck * ttlTrucks;
        double sum = sumPuzzle + sumDolls + sumBears + sumMinions + sumTrucks;
        double ttlToys = ttlPuzzle + ttlDolls + ttlBears + ttlMinions + ttlTrucks;
        if (ttlToys >= 50) {
            sum = sum * 0.75;
        }
        {   sum = sum * 0.9;
        }
        if (sum >= trip) {
            System.out.printf("Yes! %.2f lv left.", sum - trip);
        } else {
            System.out.printf("Not enough money! %.2f lv needed.", Math.abs(sum - trip));
        }
    }
}