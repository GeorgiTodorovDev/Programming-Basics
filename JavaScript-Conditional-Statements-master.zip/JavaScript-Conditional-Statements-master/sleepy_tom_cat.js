function solve(x) {
    let days = Number(x);
    let workDays = 365 - days;
    let realTimeForPlay = workDays * 63 + days * 127; // min
    let diff = Math.abs(30000 - realTimeForPlay);
    let hrs = Math.floor(diff / 60);
    let min = diff % 60;
    if (30000 <= realTimeForPlay) {
        console.log(`Tom will run away`);
        console.log(`${hrs} hours and ${min} minutes more for play`);
    } else if (30000 > realTimeForPlay) {
        console.log(`Tom sleeps well`);
        console.log(`${hrs} hours and ${min} minutes less for play`);
    }
}
solve(20);
solve(113);
