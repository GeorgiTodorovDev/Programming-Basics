function solve(x1, x2, x3) {
    let budget = Number(x1);
    let statists = Number(x2);
    let cloth = Number(x3);
    let ttlCloths = statists * cloth;
    let decor = budget * 0.1;
    if (statists > 150) {
        ttlCloths *= 0.9;
    }
    let ttlsum = decor + ttlCloths;
    if (ttlsum > budget) {
        console.log(`Not enough money!`);
        console.log(`Wingard needs ${Math.abs(ttlsum - budget).toFixed(2)} leva more.`);
    } else if (ttlsum <= budget) {
        console.log(`Action!`);
        console.log(`Wingard starts filming with ${Math.abs(ttlsum - budget).toFixed(2)} leva left.`);
    }
}
solve(20000, 120, 55.5);
solve(15437.62, 186, 57.99);
solve(9587.88, 222, 55.68);
