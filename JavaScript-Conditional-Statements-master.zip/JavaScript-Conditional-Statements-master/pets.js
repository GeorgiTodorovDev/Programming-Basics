function solve(a1, a2, a3, a4, a5) {
    let days = Number(a1);
    let kgLeft = Number(a2);
    let dogFood = Number(a3); // kg
    let catFood = Number(a4); // kg
    let turtleFood = Number(a5); // gr
    let ttlFood = dogFood * days + catFood * days + turtleFood * days / 1000;
    let dif = Math.abs(ttlFood - kgLeft);
    if (ttlFood <= kgLeft) {
        dif = Math.floor(dif)
        console.log(`${dif.toFixed(0)} kilos of food left.`);
    } else {
        dif = Math.ceil(dif)
        console.log(`${dif.toFixed(0)} more kilos of food are needed.`);
    }
}
solve(2, 10, 1, 1, 1200);
solve(5, 10, 2.1, 0.8, 321);
