function solve(shape, a, b) {    
    if(shape === "square") {
        area = a * a
        console.log((a * a).toFixed(3));
    }else if(shape === "rectangle") {
        area = a * b;
        console.log(area.toFixed(3));
    }else if(shape === "circle") {
        area = Math.PI * Math.pow(a, 2);
        console.log(area.toFixed(3));
    }else if(shape === "triangle") {
        area = a * b / 2;
        console.log(area.toFixed(3));
    }
}
solve("square", '5');
solve("rectangle", '7', '2.5');
solve("circle", '6');
solve("triangle", '4.5', '20');