function solve(a1, a2) {
    let t = String(a1);
    let n = Number(a2);
    if (t === 'Diesel') {
        if (n >= 25) {
            console.log(`You have enough ${t.toLowerCase()}.`);
        } else {
            console.log(`Fill your tank with ${t.toLowerCase()}!`);
        }
    } else if (t === 'Gas') {
        if (n >= 25) {
            console.log(`You have enough ${t.toLowerCase()}.`);
        } else {
            console.log(`Fill your tank with ${t.toLowerCase()}!`);
        }
    } else if (t === 'Gasoline') {
        if (n >= 25) {
            console.log(`You have enough ${t.toLowerCase()}.`);
        } else {
            console.log(`Fill your tank with ${t.toLowerCase()}!`);
        }
    } else {
        console.log('Invalid fuel!');
    }
}
solve('Diesel', 10);
solve('Gasoline', 40);
solve('Gas', 25);
solve('Kerosene', 200);