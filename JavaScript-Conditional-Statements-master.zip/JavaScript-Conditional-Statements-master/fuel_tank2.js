function solve(a1, a2, a3) {
    let fuelType = String(a1);
    let fuelQnty = Number(a2);
    let card = String(a3);
    if (fuelType === 'Gas') {
        if (fuelQnty > 25) {
            if (card === 'Yes') {
                let a = (0.93 - 0.08) * fuelQnty;
                let dis = a - a * 0.1;
                console.log(`${dis.toFixed(2)} lv.`)
            } else {
                let a = 0.93 * fuelQnty;
                let dis = a - a * 0.1;
                console.log(`${dis.toFixed(2)} lv.`)
            }
        } else if (fuelQnty <= 25 && fuelQnty >= 20) {
            if (card === 'Yes') {
                let a = (0.93 - 0.08) * fuelQnty;
                let dis = a - a * 0.08;
                console.log(`${dis.toFixed(2)} lv.`)
            } else {
                let a = 0.93 * fuelQnty;
                let dis = a - a * 0.08;
                console.log(`${dis.toFixed(2)} lv.`)
            }
        } else {
            if (card === 'Yes') {
                let a = (0.93 - 0.08) * fuelQnty;
                console.log(`${a.toFixed(2)} lv.`);
            } else {
                let a = 0.93 * fuelQnty;
                console.log(`${a.toFixed(2)} lv.`);
            }
        }
    } else if (fuelType === 'Gasoline') {
        if (fuelQnty > 25) {
            if (card === 'Yes') {
                let a = (2.22 - 0.18) * fuelQnty;
                let dis = a - a * 0.1;
                console.log(`${dis.toFixed(2)} lv.`)
            } else {
                let a = 2.22 * fuelQnty;
                let dis = a - a * 0.1;
                console.log(`${dis.toFixed(2)} lv.`)
            }
        } else if (fuelQnty <= 25 && fuelQnty >= 20) {
            if (card === 'Yes') {
                let a = (2.22 - 0.18) * fuelQnty;
                let dis = a - a * 0.08;
                console.log(`${dis.toFixed(2)} lv.`)
            } else {
                let a = 2.22 * fuelQnty;
                let dis = a - a * 0.08;
                console.log(`${dis.toFixed(2)} lv.`)
            }
        } else {
            if (card === 'Yes') {
                let a = (2.22 - 0.18) * fuelQnty;
                console.log(`${a.toFixed(2)} lv.`);
            } else {
                let a = 2.22 * fuelQnty;
                console.log(`{${a.toFixed(2)} lv.`);
            }
        }
    } else if (fuelType === 'Diesel') {
        if (fuelQnty > 25) {
            if (card === 'Yes') {
                let a = (2.33 - 0.12) * fuelQnty;
                let dis = a - a * 0.1;
                console.log(`${dis.toFixed(2)} lv.`)
            } else {
                let a = 2.33 * fuelQnty;
                let dis = a - a * 0.1;
                console.log(`${dis.toFixed(2)} lv.`)
            }
        } else if (fuelQnty <= 25 && fuelQnty >= 20) {
            if (card === 'Yes') {
                let a = (2.33 - 0.12) * fuelQnty;
                let dis = a - a * 0.08;
                console.log(`${dis.toFixed(2)} lv.`)
            } else {
                let a = 2.33 * fuelQnty;
                let dis = a - a * 0.08;
                console.log(`${dis.toFixed(2)} lv.`)
            }
        } else {
            if (card === 'Yes') {
                let a = (2.33 - 0.12) * fuelQnty;
                console.log(`${a.toFixed(2)} lv.`);
            } else {
                let a = 2.33 * fuelQnty;
                console.log(`${a.toFixed(2)} lv.`);
            }
        }
    }
}
solve('Gas', 30, 'Yes');
solve('Gasoline', 25, 'No');
solve('Diesel', 19, 'No');