function solve(arg1, arg2, arg3) {
    let sec1 = Number(arg1);
    let sec2 = Number(arg2);
    let sec3 = Number(arg3);
    let ttlSec = sec1 + sec2 + sec3;
    let min = Math.floor(ttlSec / 60);
    let sec = ttlSec % 60;
    if (sec < 10) {
        console.log(`${min}:0${sec}`);
    } else {
        console.log(`${min}:${sec}`);
    }
}
solve(35, 45, 44);
solve(22, 7, 34);
solve(50, 50, 49);
solve(14, 12, 10);