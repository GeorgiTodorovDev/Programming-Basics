function solve(arg1, arg2, arg3) {
    let hrsNeeded = Number(arg1);
    let limitDays = Number(arg2);
    let workersOut = Number(arg3);
    let workHrs = Math.floor((limitDays - (limitDays * 0.1)) * 8);
    let workHrsOut = Math.floor(workersOut * 2 * limitDays);
    let ttlHrs = workHrs + workHrsOut;
    if (ttlHrs >= hrsNeeded) {
        console.log(`Yes!${Math.abs(ttlHrs - hrsNeeded)} hours left.`);
    } else {
        console.log(`Not enough time!${Math.abs(ttlHrs - hrsNeeded)} hours needed.`);
    }
}
solve(90, 7, 3);
solve(99, 3, 1);
solve(50, 5, 2);