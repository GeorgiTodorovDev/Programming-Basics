function solve(a1, a2, a3, a4, a5) {
    let magnolii = Number(a1);
    let zumbuli = Number(a2);
    let rozi = Number(a3);
    let kaktusi  = Number(a4);
    let giftPrice = Number(a5);
    let ttlFlowers = magnolii * 3.25 + zumbuli * 4 + rozi * 3.5 + kaktusi * 8;
    let earning = ttlFlowers - (0.05 * ttlFlowers);
    if (earning >= giftPrice) {
        let dif = Math.abs(earning - giftPrice);
        console.log(`She is left with ${Math.floor(dif).toFixed(0)} leva.`);
    } else {
        let dif = Math.abs(earning - giftPrice);
        console.log(`She will have to borrow ${Math.ceil(dif).toFixed(0)} leva.`);
    }
}
solve(2, 3, 5, 1, 50);
solve(15, 7, 5, 10, 100);