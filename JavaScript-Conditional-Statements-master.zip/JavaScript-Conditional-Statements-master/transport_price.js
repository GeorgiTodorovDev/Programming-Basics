function solve(arg1, arg2) {
    let a = Number(arg1);
    let b = String(arg2);
    if (a >= 100) {
        if (b === 'day') {
            console.log((a * 0.06).toFixed(2));
        } else {
            console.log((a * 0.06).toFixed(2));
        }
    } else if (a < 100 && a >= 20) {
        if (b === 'day') {
            console.log((a * 0.09).toFixed(2));
        } else {
            console.log((a * 0.09).toFixed(2));
        }
    } else {
        if (b === 'day') {
            console.log((a * 0.79 + 0.7).toFixed(2));
        } else {
            console.log((a * 0.9 + 0.7).toFixed(2));
        }
    }
}
solve(5, 'day');
solve(7, 'night');
solve(25, 'day');
solve(180, 'night');
