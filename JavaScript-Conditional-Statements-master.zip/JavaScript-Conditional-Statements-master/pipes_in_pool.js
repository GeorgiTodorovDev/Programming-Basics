function solve(arg1, arg2, arg3, arg4) {
    let volume = Number(arg1);
    let p1 = Number(arg2);
    let p2 = Number(arg3);
    let h = Number(arg4);
    let P1 = p1 * h;
    let P2 = p2 * h;
    let ttl = P1 + P2;
    if (ttl <= volume) {
        let V = ttl / volume * 100;
        let pp1 = P1 / ttl * 100;
        let pp2 = P2 / ttl * 100;
        console.log(`The pool is ${V.toFixed(2)}% full. Pipe 1: ${pp1.toFixed(2)}%. Pipe 2: ${pp2.toFixed(2)}%.`);
    } else if (ttl > volume) {
        console.log(`For ${h} hours the pool overflows with ${Math.abs(ttl - volume).toFixed(2)} liters.`)
    }
}
solve(1000, 100, 120, 3);
solve(100, 100, 100, 2.5);
