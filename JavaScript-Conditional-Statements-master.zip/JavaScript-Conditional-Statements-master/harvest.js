function solve(arg1, arg2, arg3, arg4) {
    let x = Number(arg1);
    let y = Number(arg2);
    let z = Number(arg3);
    let workers = Number(arg4);
    let ttlxy = x * y;
    let wine = 0.4 * ttlxy / 2.5;
    if (wine >= z) {
        let wineLeft = Math.abs(wine - z);
        let forWorkers = wineLeft / workers;
        console.log(`Good harvest this year! Total wine: ${Math.floor(wine)} liters.`)
        console.log(`${Math.ceil(wineLeft)} liters left -> ${Math.ceil(forWorkers)} liters per person.`);
    } else if (wine < z) {
        let shortage = Math.abs(wine - z);
        console.log(`It will be a tough winter! More ${Math.floor(shortage)} liters wine needed.`);
    }
}
solve(650, 2, 175, 3);
solve(1020, 1.5, 425, 4);