function solve(x1, x2) {
    let hrs = Number(x1);
    let min = Number(x2);
    let h = hrs * 60; // min
    let ttlmin = min + h + 15; //min
    let hr = Math.floor(ttlmin / 60); 
    let m = ttlmin % 60;
    if (hr === 24) {
        hr = 0;
    } 
    if (m === 60) {
        m == 0;
    }
    if (m < 10) {
        console.log(`${hr}:0${m}`);
    } else {
        console.log(`${hr}:${m}`);
    }
}    
solve(1, 46);
solve(0, 01);
solve(23, 59);
solve(11, 08);
solve(12, 49);