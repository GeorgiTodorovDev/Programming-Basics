function solve(arg) {
    let num = Number(arg);
    if (num <= 10) {
        console.log("slow");
    } else if (num > 10 & num <=50) {
        console.log("average");
    } else if (num > 50 & num <= 150) {
        console.log("fast");
    } else if (num > 15 & num <= 1000) {
        console.log("ultra fast");
    } else {
        console.log("extremely fast")
    }
}
solve(8);
solve(49.5);
solve(126);
solve(160);
solve(3500);