function solve(num) {
    if (num >= 5.5) {
        console.log("Excellent!");
    }
}
solve(6);
solve(5);
solve(5.5);
solve(5.49);
