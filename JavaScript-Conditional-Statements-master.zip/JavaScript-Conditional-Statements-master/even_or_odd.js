function solve(num1) {
    let a = Number(num1);
    if (a % 2 === 0) {
        console.log("even");
    } else {
        console.log("odd");
    }
}
solve(2);
solve(3);
solve(25);
solve(1024);