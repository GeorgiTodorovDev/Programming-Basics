function solve(arg1, arg2, arg3, arg4, arg5, arg6) {
    let tripPrice = Number(arg1);
    let puzzles = Number(arg2);
    let dolls = Number(arg3);
    let bears = Number(arg4);
    let minions = Number(arg5);
    let trucks = Number(arg6);

    let ttlSum = puzzles * 2.6 + dolls * 3 + bears * 4.1 + minions * 8.2 + trucks * 2;
    let ttlToys = puzzles + dolls + bears + minions + trucks;

    if (ttlToys >= 50) {
        ttlSum *= 0.75;
    }
        ttlSum *= 0.9;
    if (ttlSum >= tripPrice) {
        console.log(`Yes! ${Math.abs(ttlSum - tripPrice).toFixed(2)} lv left.`);
    } else {
        console.log(`Not enough money! ${Math.abs(ttlSum - tripPrice).toFixed(2)} lv needed.`);
    }
}
solve("40.8", "20", "25", "30", "50", "10");
solve("320", "8", "2", "5", "5", "1");