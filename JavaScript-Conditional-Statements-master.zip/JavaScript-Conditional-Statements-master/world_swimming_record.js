function solve(x1, x2, x3) {
    let recInSec = Number(x1);
    let dist = Number(x2);
    let timeInSec = Number(x3);
    let delay = 0.0;
    let distInSec = dist * timeInSec; //sec
    delay = Math.floor(dist / 15) * 12.5; //sec
    let ttlTime = distInSec + delay;
    if (ttlTime >= recInSec) {
        console.log(`No, he failed! He was ${Math.abs(ttlTime - recInSec).toFixed(2)} seconds slower.`);
    } else if (ttlTime < recInSec) {
        console.log(`Yes, he succeeded! The new world record is ${ttlTime.toFixed(2)} seconds.`);
    }
}
solve(10464, 1500, 20);
solve(55555.67, 3017, 5.03);
