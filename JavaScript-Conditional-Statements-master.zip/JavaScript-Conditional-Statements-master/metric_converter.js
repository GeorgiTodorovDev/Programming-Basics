function solve(arg1, arg2, arg3) {
    let num = Number(arg1);
    let text = String(arg2);
    let text2 = String(arg3);
    if (text === "mm" & text2 == "cm") {
        console.log((num / 10).toFixed(3));
    } else if (text == "mm" & text2 == "m") {
        console.log((num / 1000).toFixed(3));
    }
    if (text == "cm" & text2 =="mm") {
        console.log((num * 10).toFixed(3));
    } else if (text == "cm" & text2 == "m") {
        console.log((num / 100).toFixed(3));
    }
    if (text == "m" & text2 == "mm") {
        console.log((num * 1000).toFixed(3));
    } else if (text == "m" & text2 == "cm") {
        console.log((num * 100).toFixed(3));
    }
}
solve(12, 'mm', 'm');
solve(150, 'm', 'cm');
solve(45, 'cm', 'mm');