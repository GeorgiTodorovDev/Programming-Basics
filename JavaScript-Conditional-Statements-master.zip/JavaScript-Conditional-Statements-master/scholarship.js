function solve(x1, x2, x3) {
    let income = Number(x1);
    let avr = Number(x2);
    let minWork = Number(x3);
    let social = 0.0;
    let grade = 0.0;
    if (income <= minWork & avr >= 4.5) {
        social = Math.floor(minWork * 0.35);
    }
    if (avr >= 5.5) {
        grade = Math.floor(avr * 25);
    }
    if (social > grade) {
        console.log(`You get a Social scholarship ${social} BGN`);
    } else if (grade > social) {
        console.log(`You get a scholarship for excellent results ${grade} BGN`);
    } else {
        console.log(`You cannot get a scholarship!`);
    }
}
solve(480, 4.6, 450);
solve(300, 5.65, 420);