n = int(input())
k = 1
while k <= n:
    print(k)
    k = 2 * k + 1
