text = str(input())
while text != "Stop":
    print(text)
    text = input()