num = int(input())
sum = 0
while True:
    n = int(input())
    sum += n
    if sum >= num:
        print(sum)
        break
