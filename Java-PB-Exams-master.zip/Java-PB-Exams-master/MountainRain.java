package PBExams;

import java.util.Scanner;

public class MountainRain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double rec = Double.parseDouble(scanner.nextLine());
        double dist = Double.parseDouble(scanner.nextLine());
        double secPerMeter = Double.parseDouble(scanner.nextLine());
        double ttlDist = dist * secPerMeter;
        double delay = Math.floor((dist / 50)) * 30;
        double ttlSec = ttlDist + delay;
        double ttl = ttlSec - rec;
        if (ttlSec < rec) {
            System.out.printf("Yes! The new record is %.2f seconds.", ttlSec);
        } else {
            System.out.printf("No! He was %.2f seconds slower.", ttl);
        }
    }
}
