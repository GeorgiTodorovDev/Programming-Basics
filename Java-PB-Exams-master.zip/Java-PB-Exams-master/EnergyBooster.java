package PBExams;

import java.util.Scanner;

public class EnergyBooster {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String fruit = scanner.nextLine();
        String size = scanner.nextLine();
        double orders = Integer.parseInt(scanner.nextLine());

        double sizeNumber = 1;
        double fruitPrice = 1;

        if (fruit.equals("Watermelon")) {
            if (size.equals("small")) {
                sizeNumber = 2;
                fruitPrice = 56;
            }
            else if (size.equals("big")) {
                sizeNumber = 5;
                fruitPrice = 28.7;
            }
        }
        switch (fruit) {
            case "Mango":
                if (size.equals("small")) {
                    sizeNumber = 2;
                    fruitPrice = 36.66;
                } else if (size.equals("big")) {
                    sizeNumber = 5;
                    fruitPrice = 19.6;
                }
                break;
            case "Pineapple":
                if (size.equals("small")) {
                    sizeNumber = 2;
                    fruitPrice = 42.1;
                } else if (size.equals("big")) {
                    sizeNumber = 5;
                    fruitPrice = 24.8;
                }
                break;
            case "Raspberry":
                if (size.equals("small")) {
                    sizeNumber = 2;
                    fruitPrice = 20;
                } else if (size.equals("big")) {
                    sizeNumber = 5;
                    fruitPrice = 15.2;
                }
                break;
        }
        double sum = sizeNumber * fruitPrice * orders;

        if (sum >= 400 && sum <= 1000) {
            System.out.printf("%.2f lv.", sum - sum * 0.15);
        } else if (sum > 1000) {
            System.out.printf("%.2f lv.", sum - sum * 0.5);
        } else if (sum < 400) {
            System.out.printf("%.2f lv.", sum);
        }
    }
}
