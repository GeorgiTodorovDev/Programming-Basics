package PBExams;

import java.util.Scanner;

public class ChangeBureau {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int bitcoin = Integer.parseInt(scanner.nextLine());
        double yuan = Double.parseDouble(scanner.nextLine());
        double com = Double.parseDouble(scanner.nextLine());

        int bc = 1168; //lv
        double yn = 0.15; //$
        double usd = 1.76; //lv
        double euro = 1.95; //lv

        int sumBc = bitcoin * bc; // lv
        double sumYuan = yuan * yn; // dollar
        double sumYuan2 = sumYuan * usd; // lv
        double sumLv = sumBc + sumYuan2;
        double sumEuro = sumLv / euro;
        double comm = sumEuro * com / 100;
        double ttl = sumEuro - comm;
        System.out.printf("%.2f", ttl);
    }
}
