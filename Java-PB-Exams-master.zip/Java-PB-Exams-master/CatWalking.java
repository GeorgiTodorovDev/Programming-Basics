package PBExams;

import java.util.Scanner;

public class CatWalking {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int minPerDay = Integer.parseInt(scanner.nextLine());
        int numWalksPerDay = Integer.parseInt(scanner.nextLine());
        int caloriesPerDay = Integer.parseInt(scanner.nextLine());
        int walks = minPerDay * numWalksPerDay;
        int ttlCal = walks * 5;
        int calEaten = caloriesPerDay - caloriesPerDay * 50 / 100;
        if (ttlCal >= calEaten) {
            System.out.printf("Yes, the walk for your cat is enough. Burned calories per day: %d.", ttlCal);
        } else  if (ttlCal < calEaten){
            System.out.printf("No, the walk for your cat is not enough. Burned calories per day: %d.", ttlCal);
        }
    }
}
