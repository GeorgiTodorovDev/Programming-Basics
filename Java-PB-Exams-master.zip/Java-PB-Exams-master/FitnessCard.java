package PBExams;

import java.util.Scanner;

public class FitnessCard {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double budget = Double.parseDouble(scanner.nextLine());
        String gender = scanner.nextLine();
        int age = Integer.parseInt(scanner.nextLine());
        String sport = scanner.nextLine();
        double sum = 0;
        if (gender.equals("m")) {
            if (sport.equals("Gym")) {
                if (age <= 19) {
                    sum = 42 * 0.8;
                } else {
                    sum = 42;
                }
            } else if (sport.equals("Boxing")) {
                if (age <= 19) {
                    sum = 41 * 0.8;
                } else {
                    sum = 41;
                }
            } else if (sport.equals("Yoga")) {
                if (age <= 19) {
                    sum = 45 * 0.8;
                } else {
                    sum = 45;
                }
            } else if (sport.equals("Zumba")) {
                if (age <= 19) {
                    sum = 34 * 0.8;
                } else {
                    sum = 34;
                }
            } else if (sport.equals("Dances")) {
                if (age <= 19) {
                    sum = 51 * 0.8;
                } else {
                    sum = 51;
                }
            } else if (sport.equals("Pilates")) {
                if (age <= 19) {
                    sum = 39 * 0.8;
                } else {
                    sum = 39;
                }
            }
        } else if (gender.equals("f")) {
            if (sport.equals("Gym")) {
                if (age <= 19) {
                    sum = 35 * 0.8;
                } else {
                    sum = 35;
                }
            } else if (sport.equals("Boxing")) {
                if (age <= 19) {
                    sum = 37 * 0.8;
                } else {
                    sum = 37;
                }
            } else if (sport.equals("Yoga")) {
                if (age <= 19) {
                    sum = 42 * 0.8;
                } else {
                    sum = 42;
                }
            } else if (sport.equals("Zumba")) {
                if (age <= 19) {
                    sum = 31 * 0.8;
                } else {
                    sum = 31;
                }
            } else if (sport.equals("Dances")) {
                if (age <= 19) {
                    sum = 53 * 0.8;
                } else {
                    sum = 53;
                }
            } else if (sport.equals("Pilates")) {
                if (age <= 19) {
                    sum = 37 * 0.8;
                } else {
                    sum = 37;
                }
            }
        }
        if (budget >= sum) {
            System.out.printf("You purchased a 1 month pass for %s.", sport);
        } else {
            System.out.printf("You don't have enough money! You need $%.2f more.", Math.abs(budget - sum));
        }
    }
}
