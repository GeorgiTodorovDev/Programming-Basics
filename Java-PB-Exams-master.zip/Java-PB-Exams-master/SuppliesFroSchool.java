package PBExams;

import java.util.Scanner;

public class SuppliesFroSchool {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int pens = Integer.parseInt(scanner.nextLine());
        int markers = Integer.parseInt(scanner.nextLine());
        double ltrDeter = Double.parseDouble(scanner.nextLine());
        double discount = Integer.parseInt(scanner.nextLine());

        double sumPens = pens * 5.8;
        double sumMarkers = markers * 7.2;
        double sumDeter = ltrDeter * 1.2;
        double ttl = sumPens + sumMarkers + sumDeter;
        double disc = discount / 100;
        double ttldisc = ttl - (ttl * disc);
        System.out.printf("%.3f", ttldisc);

    }
}
