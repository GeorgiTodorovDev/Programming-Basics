package WhileLoops;

import java.util.Scanner;

public class ExamPreparation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int lowGrades = Integer.parseInt(scanner.nextLine());
        int counterLowGrades = 0;
        int sumAllGrades = 0;
        int counterAllGrades = 0;
        String lastProblem = "";
        String input = scanner.nextLine();
        while (!input.equals("Enough")) {
            lastProblem = input;
            int curGrade = Integer.parseInt(scanner.nextLine());
            sumAllGrades += curGrade;
            counterAllGrades++;
            if (curGrade <= 4) {
                counterLowGrades++;
                if (counterLowGrades == lowGrades) {
                    break;
                }
            } else {
                counterLowGrades = 0;
            }
            input = scanner.nextLine();
        }
        double avrGrade = sumAllGrades * 1.0 / counterAllGrades;
        if (counterLowGrades == lowGrades) {
            System.out.printf("You eed a break, %d poor grades", counterLowGrades);
        } else {

        }
    }
}
