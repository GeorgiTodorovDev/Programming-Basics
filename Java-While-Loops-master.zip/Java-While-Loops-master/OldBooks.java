package WhileLoops;

import java.util.Scanner;

public class OldBooks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String favBook = scanner.nextLine();
        String curBook = scanner.nextLine();
        int counter = 0;
        boolean isFounnd = false;
        while (!curBook.equals("No More Books")) {
            if (curBook.equals(favBook)) {
                isFounnd = true;
                break;
            }
            counter++;
            curBook = scanner.nextLine();
        }
        if (isFounnd) {
            System.out.printf("You checked %d books and found it.", counter);
        } else {
            System.out.println("The book you search is not here!");
            System.out.printf("You checked %d books.", counter);
        }
    }
}
