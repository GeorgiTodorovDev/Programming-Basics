package Simple_Ops_and_Calc;

import java.util.Scanner;

public class CharityCampaign {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int days = Integer.parseInt(scanner.nextLine());
        int pastryCooks = Integer.parseInt(scanner.nextLine());
        int cakes = Integer.parseInt(scanner.nextLine());
        int waffles = Integer.parseInt(scanner.nextLine());
        int pancakes = Integer.parseInt(scanner.nextLine());
        int ttlCakes = 45 * cakes;
        double ttlWaff = 5.8 * waffles;
        double ttlPan = 3.2 * pancakes;
        double ttl = (ttlCakes + ttlPan + ttlWaff) * pastryCooks;
        double ttlSum = ttl * days;
        double sum = ttlSum - ttlSum / 8;
        System.out.printf("%.2f", sum);
    }
}
