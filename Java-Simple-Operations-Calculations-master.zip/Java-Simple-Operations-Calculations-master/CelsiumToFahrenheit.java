package Simple_Ops_and_Calc;

import java.util.Scanner;

public class CelsiumToFahrenheit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double C = Double.parseDouble(scanner.nextLine());
        double F = C * 9 / 5 + 32;
        System.out.printf("%.2f", F);
    }
}
