package Simple_Ops_and_Calc;

import java.util.Scanner;

public class ProjectCreation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();
        int a = Integer.parseInt(scanner.nextLine());
        int h = a * 3;
        System.out.println("The architect " + name + " will need " + h + " hours to complete " + a + " project/s.");
    }
}
