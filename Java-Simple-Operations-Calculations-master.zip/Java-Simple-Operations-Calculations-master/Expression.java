package Simple_Ops_and_Calc;



public class Expression {
    public static void main(String[] args) {
        System.out.println((3522 + 52353) * 23 - (2336 * 501 + 23432 - 6743) * 3);

    }
}
