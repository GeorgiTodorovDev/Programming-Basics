package Simple_Ops_and_Calc;

import java.util.Scanner;

public class VegetableMarket {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double euro = 1.94;
        double kgVg = Double.parseDouble(scanner.nextLine());
        double kgFr = Double.parseDouble(scanner.nextLine());
        double ttlVg = Double.parseDouble(scanner.nextLine());
        double ttlFr = Double.parseDouble(scanner.nextLine());
        double ttlSum1 = kgVg * ttlVg;
        double ttlSum2 = kgFr * ttlFr;
        double sum = ttlSum1 + ttlSum2;
        double sumEu = sum / euro;
        System.out.printf("%.2f", sumEu);
    }
}
