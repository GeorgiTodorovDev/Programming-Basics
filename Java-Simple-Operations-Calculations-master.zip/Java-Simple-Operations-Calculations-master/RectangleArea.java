package Simple_Ops_and_Calc;

import java.util.Scanner;

public class RectangleArea {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double x = Double.parseDouble(scanner.nextLine());
        double y = Double.parseDouble(scanner.nextLine());
        double sum = x * y;
        System.out.printf("%.2f", sum);
    }
}
