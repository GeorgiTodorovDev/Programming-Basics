package Simple_Ops_and_Calc;

import java.util.Scanner;

public class DepositCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double dep = Double.parseDouble(scanner.nextLine());
        int term = Integer.parseInt(scanner.nextLine());
        double yint = Double.parseDouble(scanner.nextLine());
        System.out.println(dep + term * ((dep * yint / 100) / 12));
    }
}
