package Simple_Ops_and_Calc;

import java.util.Scanner;

public class TrapezoidArea {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double b1 = Double.parseDouble(scanner.nextLine());
        double b2 = Double.parseDouble(scanner.nextLine());
        double h = Double.parseDouble(scanner.nextLine());
        double sum1 = b1 + b2;
        double sum2 = sum1 * h;
        double sum3 = sum2 / 2;
        System.out.printf("%.2f", sum3);
    }
}
