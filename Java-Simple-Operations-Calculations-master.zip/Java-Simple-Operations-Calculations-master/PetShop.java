package Simple_Ops_and_Calc;

import java.util.Scanner;

public class PetShop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = Integer.parseInt(scanner.nextLine());
        int b = Integer.parseInt(scanner.nextLine());
        double a1 = 2.5;
        int b1 = 4;
        double sum1 = a * a1 + b * b1;
        System.out.printf("%.2f", sum1);
        System.out.println(" lv.");
    }
}


