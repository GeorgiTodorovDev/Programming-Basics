package Simple_Ops_and_Calc;

import java.util.Scanner;

public class Fishland {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double skumriqcena = Double.parseDouble(scanner.nextLine());
        double cacacena = Double.parseDouble(scanner.nextLine());
        double palamudkg = Double.parseDouble(scanner.nextLine());
        double safridkg = Double.parseDouble(scanner.nextLine());
        double midikg = Double.parseDouble(scanner.nextLine());

        double palamudcena = skumriqcena + skumriqcena * 0.6;
        double palamudsum = palamudcena * palamudkg;
        double safridcena = cacacena + cacacena * 0.8;
        double safridsum = safridcena * safridkg;
        double midicena = midikg * 7.5;
        double sum = palamudsum + safridsum + midicena;
        System.out.printf("%.2f", sum);
    }
}
