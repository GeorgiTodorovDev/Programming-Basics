package Simple_Ops_and_Calc;

import java.util.Scanner;

public class TrainingLab {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double w = Double.parseDouble(scanner.nextLine());
        double h = Double.parseDouble(scanner.nextLine());
        double h2 = Math.floor((h * 100 - 100 ) / 70);
        double w2 = Math.floor((w * 100) / 120);
        double sum = h2 * w2 - 3;
        System.out.println(sum);

    }
}
