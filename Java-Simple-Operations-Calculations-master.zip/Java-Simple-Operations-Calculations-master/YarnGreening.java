package Simple_Ops_and_Calc;

import java.util.Scanner;

public class YarnGreening {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double input = Double.parseDouble(scanner.nextLine());
        double a = input * 7.61;
        double b = a * 0.18;
        double c = a - b;
        System.out.printf("The final price is: %.2f lv.", c);
        System.out.println();
        System.out.printf("The discount is: %.2f lv.", b);
    }
}
