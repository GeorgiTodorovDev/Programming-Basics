package Simple_Ops_and_Calc;

import java.util.Scanner;

public class FishTank {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int l = Integer.parseInt(scanner.nextLine());
        int b = Integer.parseInt(scanner.nextLine());
        int h = Integer.parseInt(scanner.nextLine());
        double percent = Double.parseDouble(scanner.nextLine());
        double v = l * b * h; //cc
        double ltrs = v / 1000;
        double prcnt = percent * 0.01;
        double ttlLtrs = ltrs * (1-prcnt);
        System.out.printf("%.3f", ttlLtrs);
    }
}
