package Simple_Ops_and_Calc;

import java.util.Scanner;

public class HousePainting {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double x = Double.parseDouble(scanner.nextLine());
        double y = Double.parseDouble(scanner.nextLine());
        double h = Double.parseDouble(scanner.nextLine());
        double oneLtrGreen = 3.4; //cubm
        double oneLtrRed = 4.3; //cubm
        //wall
        double wall = 2 * (x * x);
        double frontDoor = 1.2 * 2;
        double sumWall = wall - frontDoor;
        //sides
        double sides = 2 * (x * y);
        double windows = 2 * Math.pow(1.5, 2);
        //roof
        double roofSides = 2 * (x * y);
        double roofFrontBack = 2 * ((x * h) / 2);

        double sum = sumWall + sides - windows;
        double ttl = sum / oneLtrGreen;
        System.out.printf("%.2f", ttl);
        System.out.println();

        double sumroof = roofSides + roofFrontBack;
        double ttl2 = sumroof / oneLtrRed;
        System.out.printf("%.2f", ttl2);

    }
}
