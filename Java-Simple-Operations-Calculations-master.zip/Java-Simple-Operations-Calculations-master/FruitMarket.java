package Simple_Ops_and_Calc;

import java.util.Scanner;

public class FruitMarket {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double strPr = Double.parseDouble(scanner.nextLine());
        double banQnty = Double.parseDouble(scanner.nextLine());
        double oraQnty = Double.parseDouble(scanner.nextLine());
        double raspQnty = Double.parseDouble(scanner.nextLine());
        double strQnty = Double.parseDouble(scanner.nextLine());
        double raspPr = strPr / 2;
        double oraPr = raspPr - raspPr * 0.4;
        double banPr = raspPr - raspPr * 0.8;
        double sumStr = strPr * strQnty;
        double sumOran = oraPr * oraQnty;
        double sumRasp = raspPr * raspQnty;
        double sumBan = banPr * banQnty;
        double ttl = sumStr + sumOran + sumRasp + sumBan;
        System.out.printf("%.2f", ttl);
    }
}
