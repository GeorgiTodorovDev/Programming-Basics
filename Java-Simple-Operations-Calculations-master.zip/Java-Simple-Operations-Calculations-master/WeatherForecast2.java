package Simple_Ops_and_Calc;

import java.util.Scanner;

public class WeatherForecast2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double a = Double.parseDouble(scanner.nextLine());
        if (a >= 26.0 && a <= 35.0) {
            System.out.println("Hot");
        } else if (a >= 20.1 && a <= 25.9) {
            System.out.println("Warm");
        } else if (a >= 15.0 && a <= 20.0) {
            System.out.println("Mild");
        } else if (a >= 12.0 && a <= 14.9) {
            System.out.println("Cool");
        } else if (a >= 5.0 && a <= 11.9) {
            System.out.println("Cold");
        } else
            System.out.println("unknown");
    }
}
