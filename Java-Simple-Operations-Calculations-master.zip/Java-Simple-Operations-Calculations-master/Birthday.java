package Simple_Ops_and_Calc;

import java.util.Scanner;

public class Birthday {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int rent = Integer.parseInt(scanner.nextLine());
        double cakes = rent * 0.2;
        double drinks = cakes - cakes * 0.45;
        int animator = rent / 3;
        System.out.println(rent + cakes + drinks + animator);
    }
}
