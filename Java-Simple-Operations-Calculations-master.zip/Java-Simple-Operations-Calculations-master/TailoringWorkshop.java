package Simple_Ops_and_Calc;

import java.util.Scanner;

public class TailoringWorkshop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numRecTables = Integer.parseInt(scanner.nextLine());
        double l = Double.parseDouble(scanner.nextLine());
        double w = Double.parseDouble(scanner.nextLine());
        double usd = 1.85;
        double ttl1 = numRecTables * (l + 2 * 0.3) * (w + 2 * 0.3);
        double ttl2 = numRecTables * (l / 2) * (l / 2);
        double ttlUSD = ttl1 * 7 + ttl2 * 9;
        double ttlBGN = ttlUSD * usd;
        System.out.printf("%.2f USD%n", ttlUSD);
        System.out.printf("%.2f BGN", ttlBGN);

    }
}
