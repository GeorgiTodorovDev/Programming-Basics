package Simple_Ops_and_Calc;

import java.util.Scanner;

public class AlcoholMarket {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double priceW = Double.parseDouble(scanner.nextLine());
        double qntBeer = Double.parseDouble(scanner.nextLine());
        double qntWine = Double.parseDouble(scanner.nextLine());
        double qntRakiq = Double.parseDouble(scanner.nextLine());
        double qntWhiskey = Double.parseDouble(scanner.nextLine());

        double priceRakiq = priceW / 2;
        double priceWine = priceRakiq - priceRakiq * 0.4;
        double priceBeer = priceRakiq - priceRakiq * 0.8;
        //ttl sums
        double sumW = priceW * qntWhiskey;
        double sumB = priceBeer * qntBeer;
        double sumR = priceRakiq * qntRakiq;
        double sumWine = priceWine * qntWine;
        double ttl = sumW + sumB + sumR + sumWine;
        System.out.printf("%.2f", ttl);
    }
}
