package Simple_Ops_and_Calc;

import java.util.Scanner;

public class Text {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();
        System.out.println(name);
    }
}
