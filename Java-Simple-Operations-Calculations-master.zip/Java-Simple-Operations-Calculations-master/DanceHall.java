package Simple_Ops_and_Calc;

import java.util.Scanner;

public class DanceHall {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double L = Double.parseDouble(scanner.nextLine());
        double W = Double.parseDouble(scanner.nextLine());
        double A = Double.parseDouble(scanner.nextLine());
        double Acubcm = A * 100;
        double cc = (L * 100) * (W * 100);
        double wardrobe = Math.pow(Acubcm, 2);
        double sizeBench = cc / 10;
        double freeSpace = cc - wardrobe - sizeBench;
        double dancers = freeSpace / (40 + 7000);
        System.out.printf("%.0f", Math.floor(dancers));
    }
}
