a = str(input())
if a == 'dog':
    print("mammal")
elif a == 'crocodile' or a == 'tortoise' or a == 'snake':
    print("reptile")
else:
    print("unknown")