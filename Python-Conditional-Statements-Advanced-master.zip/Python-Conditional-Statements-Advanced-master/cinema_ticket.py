a = str(input())
if a == 'Monday' or a == 'Tuesday' or a == 'Friday':
    print(12)
elif a == 'Wednesday' or a == 'Thursday':
    print(14)
elif a == 'Saturday' or a == 'Sunday':
    print(16)
