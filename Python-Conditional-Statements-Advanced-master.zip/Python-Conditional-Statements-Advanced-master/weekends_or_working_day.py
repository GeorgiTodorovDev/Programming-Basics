a = str(input())
if a == 'Monday' or a == 'Tuesday' or a == 'Wednesday' or a == 'Thursday' or a == 'Friday':
    print("Working day")
elif a == 'Saturday' or a == 'Sunday':
    print("Weekend")
else:
    print("Error")