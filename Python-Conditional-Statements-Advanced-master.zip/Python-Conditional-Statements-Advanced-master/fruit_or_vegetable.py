a = str(input())
if a == 'banana' or a == 'apple' or a == 'kiwi' or a == 'cherry' or a == 'lemon' or a == 'grapes':
    print("fruit")
elif a == 'tomato' or a == 'cucumber' or a == 'pepper' or a == 'carrot':
    print("vegetable")
else:
    print("unknown")
