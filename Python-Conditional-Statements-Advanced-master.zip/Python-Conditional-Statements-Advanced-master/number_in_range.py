a = int(input())
if -100 <= a <= 100 and a != 0:
    print("Yes")
else:
    print("No")