a = int(input())
if 100 <= a <= 200 or a == 0:
    print()
else:
    print("invalid")