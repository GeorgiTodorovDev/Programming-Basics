i = float(input())
while i != 0:
    if i > 0:
        i *= 2
        continue
    print(f'{i:.2f}')
    i *= 2