function solve(n) {
    let sum = 0;
    for (let i = 0; i < n.length; i++) {
        if (n[i] == 'a') {
            sum += 1;
        } else if (n[i] == 'e') {
            sum += 2;
        } else if (n[i] == 'i') {
            sum += 3;
        } else if (n[i] == 'o') {
            sum += 4;
        } else if (n[i] == 'u') {
            sum += 5;
        }
    }
    console.log(sum);
}
solve("hello")
solve("hi")
solve("bamboo")
solve('beer')