function solve(n) {
    for (let i = 0; i <= n; i += 2) {
        console.log(Math.pow(2, i))
    }
}
solve(3)
solve(4)
solve(5)
solve(6)
solve(7)