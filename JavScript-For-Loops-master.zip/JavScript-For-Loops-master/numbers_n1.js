function solve(a) {
    let n = Number(a);
    for (let i = n; i >= 1; i--) {
        console.log(i)
    }
}
solve(2)
solve(3)
solve(5)