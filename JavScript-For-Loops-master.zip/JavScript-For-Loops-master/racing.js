function solve(ltr, lPerLap, laps) {
    ltr = Number(ltr);
    lPerLap = Number(lPerLap);
    laps = Number(laps);
    let outFuel = 0;

    for (let i = 1; i <= laps; i++) {
        ltr -= lPerLap;
        if (i == 1) {
            lPerLap -= 0.1;
        }

        if (ltr <= 0) {
            break;
        }
        outFuel++;     
    }
    
    if (ltr <= 0) {
        console.log(`You are out of fuel in round ${outFuel}!`);;
    } else {
        console.log(`Congrats! You won the race!`)
    } 
}
solve("70", "6.5", "10")
solve("50", "4.3", "30")