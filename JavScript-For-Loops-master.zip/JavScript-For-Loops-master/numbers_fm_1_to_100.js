function solve() {
    for (let i = 1; i <= 100; i++) {
        console.log(i);
    }
}
solve()