function solve(n1, n2) {
    n1 = Number(n1);
    n2 = Number(n2);
    for (let i = n1; i <= n2; i += 4) {
        console.log(i)
    }  
}
solve("1908",
"1919")
solve("2000",
"2011")