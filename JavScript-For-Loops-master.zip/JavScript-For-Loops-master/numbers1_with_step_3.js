function solve(n) {
    for (let i = 1; i <= n; i += 3) {
        console.log(i)
    }
}
solve(10)
solve(7)
solve(15)