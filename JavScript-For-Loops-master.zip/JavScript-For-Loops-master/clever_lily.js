function solve([a1, a2, a3]) {
    let age = Number(a1);
    let washMachine = Number(a2);
    let pricePerToy = Number(a3);
    let ttlToys = 0;
    let moneyPerYear = 0;
    let sum = 0;
    for (let i = 1; i <= age; i++) {
        if (i % 2 == 0)  {
            moneyPerYear += 10;
            sum += moneyPerYear - 1;
        } else {
            ttlToys++;
        }
    }
    ttlToys *= pricePerToy;
    sum += ttlToys;
    if (sum >= washMachine) {
        console.log(`Yes! ${Math.abs(sum - washMachine).toFixed(2)}`);
    } else {
        console.log(`No! ${Math.abs(sum - washMachine).toFixed(2)}`);
    }
}
solve(10, 170, 6)
solve(21, 1570.98, 3)