function solve(n) {
    let face = 1;
    for (let i = 1; i <= n; i++) {
        face *= i;
    }
    console.log(face)
}
solve("4")