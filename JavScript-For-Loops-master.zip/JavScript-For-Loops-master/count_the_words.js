function solve(text) {
    let words = 1;
    for (let i = 0; i < text.length; i++) {
        let a = text[i];
        if (a == " ") {
            words++;
        } 
    }
    if (words > 10) {
        console.log(`The message is too long to be send! Has ${words} words.`)
    } else {
        console.log(`The message was send successfully!`)
    }
}
solve("This message has exactly eleven words. One more as it's allowed!")
solve("This message has ten words and you can send it!")