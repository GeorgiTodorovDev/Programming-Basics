function solve(n) {
    for (let i = 0; i < n.length; i++) {
        let letter = n[i];
        console.log(letter)
    }
}
solve("softuni")
solve("ice cream")