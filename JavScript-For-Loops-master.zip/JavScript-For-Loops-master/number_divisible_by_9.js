function solve(n1, n2) {
    n1 = Number(n1);
    n2 = Number(n2);
    sum = 0;
    let output = "";
    for (let i = n1; i <= n2; i++) {
        if (i % 9 == 0) {
            sum += i;
            output += i + " ";
        }
    }
    console.log(`The sum: ${sum}`);
    console.log(output); 
}
solve(100, 200)