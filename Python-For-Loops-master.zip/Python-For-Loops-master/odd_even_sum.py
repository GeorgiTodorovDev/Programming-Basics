n = int(input())
even = 0
odd = 0

for i in range(n):
    num = int(input())
    if i % 2 == 0:
        even += num
    else:
        odd += num
if even == odd:
    print(f'Yes, sum = {even}')
else:
    print(f'No, diff = {abs(even - odd)}')
