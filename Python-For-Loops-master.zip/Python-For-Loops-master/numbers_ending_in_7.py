for i in range(7, 1000, 10):
    print(i)
