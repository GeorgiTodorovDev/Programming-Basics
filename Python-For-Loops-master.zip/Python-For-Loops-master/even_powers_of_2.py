n = int(input())
for i in range(0, n + 1, 2):
    print(2 ** i)
