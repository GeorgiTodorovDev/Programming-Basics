for i in range(23 + 1):
    for j in range(59 + 1):
        for k in range(59 + 1):
            print(f'{i} : {j} : {k}')
