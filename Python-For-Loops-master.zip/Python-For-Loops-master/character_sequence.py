text = str(input())
for i in range(0, len(text)):
    print(text[i])