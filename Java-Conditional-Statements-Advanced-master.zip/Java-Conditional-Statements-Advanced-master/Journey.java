package Conditional_Statements_Advanced;

import com.sun.nio.sctp.AbstractNotificationHandler;

import java.util.Scanner;

public class Journey {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double budget = Double.parseDouble(scanner.nextLine());
        String season = scanner.nextLine();
        String dest = "";
        String vac = "";
        if (budget <= 100) {
            dest = "Bulgaria";
            if (season.equals("summer")) {
                vac = "Camp";
                budget *= 0.3;
            } else {
                vac = "Hotel";
                budget *= 0.7;
            }
        } else if (budget <= 1000) {
            dest = "Balkans";
            if (season.equals("summer")) {
                vac = "Camp";
                budget *= 0.4;
            } else {
                vac = "Hotel";
                budget *= 0.8;
            }
        } else {
            dest = "Europe";
            vac = "Hotel";
            budget *= 0.9;
        }
        System.out.printf("Somewhere in %s%n", dest);
        System.out.printf("%s - %.2f", vac, budget);
    }
}
