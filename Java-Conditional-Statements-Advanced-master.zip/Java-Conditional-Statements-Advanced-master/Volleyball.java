package Conditional_Statements_Advanced;

import java.util.Scanner;

public class Volleyball {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String year = scanner.nextLine();
        double holidays = Double.parseDouble(scanner.nextLine());
        int homeWeekends = Integer.parseInt(scanner.nextLine());
        double sofiaWeekends = 48 - homeWeekends;
        double sofiaGames = sofiaWeekends * 3 / 4;
        double sofiaHolidays = holidays * 2 / 3;
        double ttlGames = sofiaGames + sofiaHolidays + homeWeekends;
        if (year.equals("leap")) {
            ttlGames *= 1.15;
            System.out.printf("%.0f", Math.floor(ttlGames));
        } else {
            System.out.printf("%.0f", Math.floor(ttlGames));
        }
    }
}
