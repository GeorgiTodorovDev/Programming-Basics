package Conditional_Statements_Advanced;

import java.util.Scanner;

public class TradeCommissions {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String town = scanner.nextLine();
        double a = Double.parseDouble(scanner.nextLine());
        double sum = 0.0;
        if (town.equals("Sofia")) {
            if (0 <= a && a <= 500) {
                sum = a * 0.05;
                System.out.printf("%.2f", sum);
            } else if (500 < a && a <= 1000) {
                sum = a * 0.07;
                System.out.printf("%.2f", sum);
            } else if (1000 < a && a <= 10000) {
                sum = a * 0.08;
                System.out.printf("%.2f", sum);
            } else if (a > 10000) {
                sum = a * 0.12;
                System.out.printf("%.2f", sum);
            } else {
                System.out.println("error");
            }
        } else if (town.equals("Varna")) {
            if (0 <= a && a <= 500) {
                sum = a * 0.045;
                System.out.printf("%.2f", sum);
            } else if (500 < a && a <= 1000) {
                sum = a * 0.075;
                System.out.printf("%.2f", sum);
            } else if (1000 < a && a <= 10000) {
                sum = a * 0.1;
                System.out.printf("%.2f", sum);
            } else if (a > 10000) {
                sum = a * 0.13;
                System.out.printf("%.2f", sum);
            } else {
                System.out.println("error");
            }
        } else if (town.equals("Plovdiv")) {
            if (0 <= a && a <= 500) {
                sum = a * 0.055;
                System.out.printf("%.2f", sum);
            } else if (500 < a && a <= 1000) {
                sum = a * 0.08;
                System.out.printf("%.2f", sum);
            } else if (1000 < a && a <= 10000) {
                sum = a * 0.12;
                System.out.printf("%.2f", sum);
            } else if (a > 10000) {
                sum = a * 0.145;
                System.out.printf("%.2f", sum);
            } else {
                System.out.println("error");
            }
        } else {
            System.out.println("error");
        }
    }
}
