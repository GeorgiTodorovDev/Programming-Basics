package Conditional_Statements_Advanced;

import java.util.Scanner;

public class FruitShop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String fruit = scanner.nextLine();
        String day = scanner.nextLine();
        double q = Double.parseDouble(scanner.nextLine());
        double sum = 0.0;
        if (day.equals("Monday") || day.equals("Tuesday") || day.equals("Wednesday") || day.equals("Thursday") ||
                day.equals("Friday")) {
            if (fruit.equals("banana")) {
                sum = q * 2.5;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("apple")) {
                sum = q * 1.2;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("orange")) {
                sum = q * 0.85;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("grapefruit")) {
                sum = q * 1.45;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("kiwi")) {
                sum = q * 2.7;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("pineapple")) {
                sum = q * 5.5;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("grapes")) {
                sum = q * 3.85;
                System.out.printf("%.2f", sum);
            } else {
                System.out.println("error");
            }
        } else if (day.equals("Saturday") || day.equals("Sunday")) {
            if (fruit.equals("banana")) {
                sum = q * 2.7;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("apple")) {
                sum = q * 1.25;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("orange")) {
                sum = q * 0.9;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("grapefruit")) {
                sum = q * 1.6;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("kiwi")) {
                sum = q * 3;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("pineapple")) {
                sum = q * 5.6;
                System.out.printf("%.2f", sum);
            } else if (fruit.equals("grapes")) {
                sum = q * 4.2;
                System.out.printf("%.2f", sum);
            } else {
                System.out.println("error");
            }
        } else {
            System.out.println("error");
        }
    }
}
