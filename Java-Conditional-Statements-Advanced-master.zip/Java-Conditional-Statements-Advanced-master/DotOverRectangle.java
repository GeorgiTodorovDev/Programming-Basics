package Conditional_Statements_Advanced;

import java.util.Scanner;

public class DotOverRectangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int x1 = Integer.parseInt(scanner.nextLine());
        int y1 = Integer.parseInt(scanner.nextLine());
        int x2 = Integer.parseInt(scanner.nextLine());
        int y2 = Integer.parseInt(scanner.nextLine());
        int x = Integer.parseInt(scanner.nextLine());
        int y = Integer.parseInt(scanner.nextLine());
        boolean a = (x == x1 || x == x2) && (y <= y1 || y <= y2);
        boolean a1 = (y == y1 || y == y2) && (x <= x1 || x <= x2);
        if (a || a1) {
            System.out.printf("Border");
        } else {
            System.out.println("Inside / Outside");
        }
    }
}
