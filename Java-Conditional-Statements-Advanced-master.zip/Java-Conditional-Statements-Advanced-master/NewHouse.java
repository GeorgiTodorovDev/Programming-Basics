package Conditional_Statements_Advanced;

import java.util.Scanner;

public class NewHouse {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String flower = scanner.nextLine();
        int num = Integer.parseInt(scanner.nextLine());
        int budget = Integer.parseInt(scanner.nextLine());
        double sum = 0.0;
        if (flower.equals("Roses")) {
            if (num > 80) {
                sum = num * 5;
                sum *= 0.9;
            } else {
                sum = num * 5;
            }
        } else if (flower.equals("Dahlias")) {
            if (num > 90) {
                sum = num * 3.8;
                sum *= 0.85;
            } else {
                sum = num * 3.8;
            }
        } else if (flower.equals("Tulips")) {
            if (num > 80) {
                sum = num * 2.8;
                sum *= 0.85;
            } else {
                sum = num * 2.8;
            }
        } else if (flower.equals("Narcissus")) {
            if (num < 120) {
                sum = num * 3;
                sum *= 1.15;
            } else {
                sum = num * 3;
            }
        } else if (flower.equals("Gladiolus")) {
            if (num < 80) {
                sum = num * 2.5;
                sum *= 1.2;
            } else {
                sum = num * 2.5;
            }
        }
        if (budget >= sum) {
            System.out.printf("Hey, you have a great garden with %d %s and %.2f leva left.", num, flower, Math.abs(budget - sum));
        } else {
            System.out.printf("Not enough money, you need %.2f leva more.", Math.abs(budget - sum));
        }
    }
}
