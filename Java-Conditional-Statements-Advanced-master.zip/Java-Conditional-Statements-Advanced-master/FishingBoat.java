package Conditional_Statements_Advanced;

import java.util.Scanner;

public class FishingBoat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int budget = Integer.parseInt(scanner.nextLine());
        String season = scanner.nextLine();
        int fishermen = Integer.parseInt(scanner.nextLine());
        double rent = 0;
        if (season.equals("Spring")) {
            rent = 3000;
        } else if (season.equals("Summer") || season.equals("Autumn")) {
            rent = 4200;
        } else if (season.equals("Winter")) {
            rent = 2600;
        }
        if (fishermen <= 6) {
            rent *= 0.9;
        } else if (fishermen <= 11) {
            rent *= 0.85;
        } else {
            rent *= 0.75;
        }
        if (fishermen % 2 == 0 && !season.equals("Autumn")) {
            rent *= 0.95;
        }
        if (budget >= rent) {
            System.out.printf("Yes! You have %.2f leva left.", Math.abs(budget - rent));
        } else {
            System.out.printf("Not enough money! You need %.2f leva.", Math.abs(budget - rent));
        }
    }
}
