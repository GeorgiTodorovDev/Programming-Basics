package Conditional_Statements_Advanced;

import java.util.Scanner;

public class InvalidNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double a = Double.parseDouble(scanner.nextLine());
        if (a >= 100 && a <= 200 || a == 0) {

        } else {
            System.out.println("invalid");
        }
    }
}
