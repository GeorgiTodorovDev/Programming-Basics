package Conditional_Statements_Advanced;

import java.util.Scanner;

public class SunnerOutfit {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int deg = Integer.parseInt(scanner.nextLine());
        String dayTime = scanner.nextLine();
        String outfit = "";
        String shoes = "";
        if (10 <= deg && deg <= 18) {
            if (dayTime.equals("Morning")) {
                outfit = "Sweatshirt";
                shoes = "Sneakers";
            } else if (dayTime.equals("Afternoon")) {
                outfit = "Shirt";
                shoes = "Moccasins";
            } else {
                outfit = "Shirt";
                shoes = "Moccasins";
            }
        } else if (18 < deg && deg <= 24) {
            if (dayTime.equals("Morning")) {
                outfit = "Shirt";
                shoes = "Moccasins";
            } else if (dayTime.equals("Afternoon")) {
                outfit = "T-Shirt";
                shoes = "Sandals";
            } else {
                outfit = "Shirt";
                shoes = "Moccasins";
            }
        } else if (deg >= 25) {
            if (dayTime.equals("Morning")) {
                outfit = "T-Shirt";
                shoes = "Sandals";
            } else if (dayTime.equals("Afternoon")) {
                outfit = "Swim Suit";
                shoes = "Barefoot";
            } else {
                outfit = "Shirt";
                shoes = "Moccasins";
            }
        }
        System.out.printf("It's %d degrees, get your %s and %s.", deg, outfit, shoes);
    }
}
