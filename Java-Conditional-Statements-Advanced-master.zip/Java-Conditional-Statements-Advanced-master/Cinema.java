package Conditional_Statements_Advanced;

import java.util.Scanner;

public class Cinema {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String film = scanner.nextLine();
        double rows = Double.parseDouble(scanner.nextLine());
        double columns = Double.parseDouble(scanner.nextLine());
        if (film.equals("Premiere")) {
            System.out.printf("%.2f leva", (rows * columns * 12));
        } else if (film.equals("Normal")) {
            System.out.printf("%.2f leva", (rows * columns * 7.5));
        } else {
            System.out.printf("%.2f leva", (rows * columns * 5));
        }
    }
}
