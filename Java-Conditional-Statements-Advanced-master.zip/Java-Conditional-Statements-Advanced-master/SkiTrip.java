package Conditional_Statements_Advanced;

import java.util.Scanner;

public class SkiTrip {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int days = Integer.parseInt(scanner.nextLine());
        String room = scanner.nextLine();
        String eval = scanner.nextLine();
        double sum = 0;
        if (room.equals("room for one person")) {
            if (days <= 10) {
                sum = (days - 1) * 18;
            } else if (days > 10 && days <= 15) {
                sum = (days - 1) * 18;
            } else if (days > 15) {
                sum = (days - 1) * 18;
            }
        } else if (room.equals("apartment")) {
            if (days <= 10) {
                sum = (days - 1) * 25;
                sum *= 0.7;
            } else if (days > 10 && days <= 15) {
                sum = (days - 1) * 25;
                sum *= 0.65;
            } else if (days > 15) {
                sum = (days - 1) * 25;
                sum *= 0.5;
            }
        } else if (room.equals("president apartment")) {
            if (days <= 10) {
                sum = (days - 1) * 35;
                sum *= 0.9;
            } else if (days > 10 && days <= 15) {
                sum = (days - 1) * 35;
                sum *= 0.85;
            } else if (days > 15) {
                sum = (days - 1) * 35;
                sum *= 0.8;
            }
        }
        if (eval.equals("positive")) {
            sum += sum * 0.25;
        } else {
            sum *= 0.9;
        }
        System.out.printf("%.2f", sum);
    }
}
