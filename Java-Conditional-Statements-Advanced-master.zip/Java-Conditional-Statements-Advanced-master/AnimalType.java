package Conditional_Statements_Advanced;

import java.util.Scanner;

public class AnimalType {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String a = scanner.nextLine();
        if (a.equals("dog")) {
            System.out.println("mammal");
        } else if (a.equals("tortoise") || a.equals("snake") || a.equals("crocodile")) {
            System.out.println("reptile");
        } else {
            System.out.println("unknown");
        }
    }
}
