package Conditional_Statements_Advanced;

import java.util.Scanner;

public class PersonalTitles {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        double a = Double.parseDouble(scanner.nextLine());
        String b = scanner.nextLine();
        if (b.equals("m")) {
            if (a >= 16) {
                System.out.println("Mr.");
            } else {
                System.out.println("Master");
            }
        } else if (b.equals("f")) {
            if (a >= 16) {
                System.out.println("Ms.");
            } else {
                System.out.println("Miss");
            }
        }
    }
}
