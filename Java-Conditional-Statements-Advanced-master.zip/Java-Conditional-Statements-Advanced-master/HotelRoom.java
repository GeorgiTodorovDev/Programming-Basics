package Conditional_Statements_Advanced;

import java.awt.font.TextLayout;
import java.util.Scanner;

public class HotelRoom {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String month = scanner.nextLine();
        int nights = Integer.parseInt(scanner.nextLine());
        double studio = 0;
        double apartment = 0;
        if (month.equals("May") || month.equals("October")) {
            if (nights > 7 && nights <= 14) {
                studio = nights * 50;
                studio *= 0.95;
                apartment = nights * 65;
            } else if (nights > 14) {
                studio = nights * 50;
                studio *= 0.7;
                apartment = nights * 65;
                apartment *= 0.9;
            } else {
                studio = nights * 50;
                apartment = nights * 65;
            }
        } else if (month.equals("June") || month.equals("September")) {
            if (nights > 14) {
                studio = nights * 75.2;
                studio *= 0.8;
                apartment = nights * 68.7;
                apartment *= 0.9;
            } else {
                studio = nights * 75.2;
                apartment = nights * 68.7;
            }
        } else if (month.equals("July") || month.equals("August")) {
            if (nights > 14) {
                studio = nights * 76;
                apartment = nights * 77;
                apartment *= 0.9;
            } else {
                studio = nights * 76;
                apartment = nights * 77;
            }
        }
        System.out.printf("Apartment: %.2f lv.%n", apartment);
        System.out.printf("Studio: %.2f lv.", studio);
    }
}
