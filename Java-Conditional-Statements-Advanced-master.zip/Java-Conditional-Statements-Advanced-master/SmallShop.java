package Conditional_Statements_Advanced;

import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;

public class SmallShop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String product = scanner.nextLine();
        String town = scanner.nextLine();
        double a = Double.parseDouble(scanner.nextLine());
        double sum = 0.0;
        if (product.equals("coffee")) {
            if (town.equals("Sofia")) {
                sum = a * 0.5;
            } else if (town.equals("Plovdiv")) {
                sum = a * 0.4;
            } else if (town.equals("Varna")) {
                sum = a * 0.45;
            }
        } else if (product.equals("water")) {
            if (town.equals("Sofia")) {
                sum = a * 0.8;
            } else if (town.equals("Plovdiv")) {
                sum = a * 0.7;
            } else if (town.equals("Varna")) {
                sum = a * 0.7;
            }
        } else if (product.equals("beer")) {
            if (town.equals("Sofia")) {
                sum = a * 1.2;
            } else if (town.equals("Plovdiv")) {
                sum = a * 1.15;
            } else if (town.equals("Varna")) {
                sum = a * 1.1;
            }
        } else if (product.equals("sweets")) {
            if (town.equals("Sofia")) {
                sum = a * 1.45;
            } else if (town.equals("Plovdiv")) {
                sum = a * 1.3;
            } else if (town.equals("Varna")) {
                sum = a * 1.35;
            }
        } else if (product.equals("peanuts")) {
            if (town.equals("Sofia")) {
                sum = a * 1.6;
            } else if (town.equals("Plovdiv")) {
                sum = a * 1.5;
            } else if (town.equals("Varna")) {
                sum = a * 1.55;
            }
        }
        System.out.println(sum);
    }
}
