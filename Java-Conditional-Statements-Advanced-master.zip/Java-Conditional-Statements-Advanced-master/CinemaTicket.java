package Conditional_Statements_Advanced;

import java.util.Scanner;

public class CinemaTicket {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String a = scanner.nextLine();
        if (a.equals("Monday") || a.equals("Tuesday") || a.equals("Friday")) {
            System.out.println(12);
        } else if (a.equals("Wednesday") || a.equals("Thursday")) {
            System.out.println(14);
        } else {
            System.out.println(16);
        }
    }
}
